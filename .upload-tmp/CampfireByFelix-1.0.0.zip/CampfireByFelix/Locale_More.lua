--=====================================================================
--  Campfire by Felix - more languages (frFR, esES, esMX, itIT, ptBR, ruRU, koKR, zhCN, zhTW)
--=====================================================================
local _, ns = ...

ns.LOCALES.frFR = {
    optDesc        = "Tout le camping de WoW Forever dans une seule fenêtre : ce que vos métiers peuvent installer près d'un feu de camp, ce qui vous manque encore, où tombe chaque plan, les conflits d'améliorations et un plan de camp pour votre groupe. S'ouvre tout seul quand vous arrivez près d'un feu.",
    optAutoOpen    = "Ouvrir la fenêtre quand j'arrive près d'un feu de camp",
    optAutoClose   = "La refermer quand je m'éloigne (si elle s'est ouverte toute seule)",
    optGroup       = "Partager ce que je peux apporter avec mon groupe / raid (utilisateurs de Campfire by Felix)",
    optMinimap     = "Afficher le bouton de la minicarte",
    btnOpen        = "Ouvrir Campfire by Felix",
    ttLeft         = "Clic gauche : ouvrir / fermer",
    ttRight        = "Clic droit : paramètres",
    ttDrag         = "Glisser : déplacer ce bouton",
    msgAutoOn      = "S'ouvre automatiquement près des feux de camp.",
    msgAutoOff     = "Ne s'ouvre plus automatiquement.",
    msgCombat      = "Impossible en combat - réessayez ensuite.",
    msgOpenProf    = "Ouvrez la fenêtre de votre métier pour le fabriquer.",
    msgHelp        = "/cfm - ouvrir / fermer, /cfm guide, /cfm group, /cfm auto - ouverture auto oui/non, /cfm options",

    hdrCamp        = "Camp",
    hdrProfessions = "Métiers",
    navOverview    = "Vue d'ensemble",
    navOverviewSub = "tout en un coup d'œil",
    navFire        = "Feux de camp",
    navFireSub     = "kits, emplacements, plans",
    navGroup       = "Plan de groupe",
    navGroupSub    = "qui apporte quoi",
    navGuide       = "Guide",
    navGuideSub    = "comment fonctionne le camping",

    hdrNoFire      = "Aucun feu de camp à proximité",
    hdrFireUnknown = "Feu de camp à proximité - survolez le feu pour voir sa taille",
    hdrFire        = "%s à proximité  -  %d / %d emplacements vus",
    hdrCooldown    = "Temps de recharge du camp :",
    hdrBuff        = "Amélioration de camp :",
    ready          = "prêt",
    none           = "aucune",

    fire_basic      = "Feu de camp simple",
    fire_journeyman = "Feu de camp de compagnon",
    fire_expert     = "Feu de camp d'expert",
    fireTier       = "%s %d  -  %d emplacements",
    fireSub        = "La cuisine crée le feu. Plus le feu est grand, plus il accueille d'objets de camp - un par joueur.",
    fireEffect     = "Allume un feu de camp pendant environ 15 minutes. Les autres joueurs y ajoutent leurs objets de camp.",
    objTier        = "%s %d",

    stBags         = "Dans vos sacs - à installer",
    stCraft        = "Vous pouvez le fabriquer",
    stLearn        = "Apprendre la recette",
    stSkill        = "encore %d points de compétence",
    stNone         = "Métier non appris",
    atFire         = "Déjà près de ce feu",
    sideReady      = "%d prêt(s)",
    profSkill      = "Compétence %d / %d",
    profNone       = "non appris",

    source         = "Apprendre",
    srcTrainer     = "maître de métier ou la quête « Camping 101 »",
    srcTrainerCooking = "Maître de cuisine",
    blueprint      = "Plan",
    bpInBags       = "(dans vos sacs - utilisez-le !)",
    reagents       = "Composants",
    inBank         = "(banque)",
    conflictInfo   = "Ne se cumule pas avec %s.",
    conflictActive = "Vous avez %s - cette amélioration de camp ne fonctionne pas pour vous en ce moment.",
    conflictShort  = "bloqué",

    btnCraft       = "Fabriquer",
    btnPlace       = "Installer",
    btnPlaceNoFire = "Installer (feu requis)",

    colObject      = "Objet de camp",
    colProfession  = "Métier",
    colStatus      = "Statut",
    overviewSub    = "%d à installer, %d à fabriquer, %d recettes à apprendre - cliquez sur une ligne pour les détails",
    ttOpenProf     = "Clic : ouvrir la page de ce métier",

    groupSolo      = "Vous n'êtes pas en groupe. Rejoignez-en un : les membres qui utilisent Campfire by Felix apparaissent ici.",
    groupSub       = "%d membre(s) du groupe avec Campfire by Felix. Un objet par joueur - voici la meilleure répartition :",
    planReady      = "(prêt)",
    planCraft      = "(à fabriquer d'abord)",
    planEmpty      = "Personne ne peut encore rien apporter - consultez la Vue d'ensemble pour savoir quoi fabriquer.",
    alreadyAtFire  = "Déjà près du feu :",
    groupHint      = "Les objets à amélioration passent en premier, car ils profitent à tous ; ensuite les stations supérieures. Les membres sans l'addon ne sont pas listés.",

    guideSub       = "Court et pratique - tout ce que vous devez savoir.",
    guide = [[
|cffff9a3cLe feu de camp|r
La cuisine permet de fabriquer un kit de feu de camp (%WOOD% + %FLINT% pour le simple). Utilisez le kit en extérieur et le feu brûle environ 15 minutes. Impossible d'allumer un feu à moins de 100 mètres d'un autre.
  Feu de camp simple : 3 emplacements  -  Compagnon : 5 emplacements  -  Expert : 10 emplacements

|cffff9a3cObjets de camp|r
Chaque métier peut ajouter un objet par joueur à un feu : à 20, 140 et 300 de compétence. Fabriquez d'abord l'objet (il va dans vos sacs), puis utilisez-le près du feu. Tous les objets de camp partagent un temps de recharge d'une heure. Un rang supérieur de votre métier remplace le précédent.

|cffff9a3cObtenir les améliorations|r
Reposez-vous 1 minute près du feu : asseyez-vous, utilisez une chaise, dormez, allongez-vous ou agenouillez-vous. Lancer des sorts et fabriquer est autorisé. Vous obtenez « %BENEFITS% » pendant 1 heure - l'effet reste quand vous partez. Rasseyez-vous pour profiter des objets installés plus tard.

|cffff9a3cConflits d'améliorations|r
Les améliorations de camp ne se cumulent pas avec l'amélioration de classe correspondante :
%CONFLICTS%
Campfire by Felix affiche un objet de camp en rouge quand une telle amélioration est sur vous.

|cffff9a3cRecettes et plans|r
Rang 1 (compétence 20) : auprès de votre maître de métier ou via la quête « Camping 101 ».
Rangs 2 et 3 (140 / 300) : plans lâchés par des boss - chaque page de métier indique quel boss et où. Utilisez le plan pour apprendre la recette.

|cffff9a3cAstuces|r
  La tente de camp recharge l'XP de repos (une fois par heure) - idéal pendant la montée en niveau.
  Le robot de réparation de l'ingénierie répare et vend ; le robot à composants vend des composants.
  La serre de l'herboristerie fait pousser des herbes à partir de graines, le jardin de pierres fait apparaître du minerai.
  En groupe, ouvrez « Plan de groupe » avant d'allumer le feu : un objet par joueur, pas de doublons.

/cfm - ouvrir  -  /cfm guide  -  /cfm group  -  /cfm options]],
}

ns.LOCALES.esES = {
    optDesc        = "Todo sobre la acampada de WoW Forever en una sola ventana: qué pueden colocar tus profesiones en una hoguera, qué te falta todavía, dónde cae cada plano, conflictos de beneficios y un plan de campamento para tu grupo. Se abre solo al llegar a una hoguera.",
    optAutoOpen    = "Abrir la ventana al llegar a una hoguera",
    optAutoClose   = "Cerrarla al alejarme (si se abrió sola)",
    optGroup       = "Compartir con mi grupo / banda lo que puedo aportar (usuarios de Campfire by Felix)",
    optMinimap     = "Mostrar el botón del minimapa",
    btnOpen        = "Abrir Campfire by Felix",
    ttLeft         = "Clic izquierdo: abrir / cerrar",
    ttRight        = "Clic derecho: opciones",
    ttDrag         = "Arrastrar: mover este botón",
    msgAutoOn      = "Se abre automáticamente en las hogueras.",
    msgAutoOff     = "Ya no se abre automáticamente.",
    msgCombat      = "No en combate - inténtalo de nuevo después.",
    msgOpenProf    = "Abre la ventana de tu profesión para fabricarlo.",
    msgHelp        = "/cfm - abrir / cerrar, /cfm guide, /cfm group, /cfm auto - activar/desactivar apertura automática, /cfm options",

    hdrCamp        = "Campamento",
    hdrProfessions = "Profesiones",
    navOverview    = "Resumen",
    navOverviewSub = "todo de un vistazo",
    navFire        = "Hogueras",
    navFireSub     = "kits, huecos, planos",
    navGroup       = "Plan de grupo",
    navGroupSub    = "quién trae qué",
    navGuide       = "Guía",
    navGuideSub    = "cómo funciona la acampada",

    hdrNoFire      = "No hay ninguna hoguera cerca",
    hdrFireUnknown = "Hoguera cerca - pasa el ratón por encima del fuego para ver su tamaño",
    hdrFire        = "%s cerca  -  %d / %d huecos vistos",
    hdrCooldown    = "Tiempo de reutilización del campamento:",
    hdrBuff        = "Beneficio del campamento:",
    ready          = "listo",
    none           = "ninguno",

    fire_basic      = "Hoguera básica",
    fire_journeyman = "Hoguera de oficial",
    fire_expert     = "Hoguera de experto",
    fireTier       = "%s %d  -  %d huecos",
    fireSub        = "La cocina crea la hoguera. Las hogueras más grandes admiten más objetos de campamento - uno por jugador.",
    fireEffect     = "Enciende una hoguera durante unos 15 minutos. Otros jugadores añaden sus objetos de campamento.",
    objTier        = "%s %d",

    stBags         = "En tus bolsas - colócalo",
    stCraft        = "Puedes fabricarlo",
    stLearn        = "Aprende la receta",
    stSkill        = "%d de habilidad más",
    stNone         = "Profesión no aprendida",
    atFire         = "Ya está en esta hoguera",
    sideReady      = "%d listos",
    profSkill      = "Habilidad %d / %d",
    profNone       = "sin aprender",

    source         = "Aprender",
    srcTrainer     = "instructor de profesión o la misión \"Camping 101\"",
    srcTrainerCooking = "Instructor de cocina",
    blueprint      = "Plano",
    bpInBags       = "(en tus bolsas - ¡úsalo!)",
    reagents       = "Componentes",
    inBank         = "(banco)",
    conflictInfo   = "No se acumula con %s.",
    conflictActive = "Tienes %s - este beneficio de campamento no te funciona ahora mismo.",
    conflictShort  = "bloqueado",

    btnCraft       = "Fabricar",
    btnPlace       = "Colocar ya",
    btnPlaceNoFire = "Colocar (requiere hoguera)",

    colObject      = "Objeto de campamento",
    colProfession  = "Profesión",
    colStatus      = "Estado",
    overviewSub    = "%d para colocar, %d para fabricar, %d recetas por aprender - haz clic en una fila para ver detalles",
    ttOpenProf     = "Clic: abrir la página de esta profesión",

    groupSolo      = "No estás en un grupo. Únete a uno: los miembros que usan Campfire by Felix aparecen aquí.",
    groupSub       = "%d miembro(s) del grupo con Campfire by Felix. Un objeto por jugador - este es el mejor reparto:",
    planReady      = "(listo)",
    planCraft      = "(fabricar primero)",
    planEmpty      = "Nadie puede aportar nada todavía - mira el Resumen para ver qué fabricar.",
    alreadyAtFire  = "Ya en la hoguera:",
    groupHint      = "Los objetos con beneficios van primero porque ayudan a todos; después, las estaciones superiores. Los miembros sin el addon no aparecen.",

    guideSub       = "Breve y práctico - todo lo que necesitas saber.",
    guide = [[
|cffff9a3cLa hoguera|r
La cocina crea un kit de hoguera (%WOOD% + %FLINT% para la básica). Usa el kit al aire libre y la hoguera arde unos 15 minutos. No puedes encender una hoguera a menos de 100 metros de otra.
  Hoguera básica: 3 huecos  -  Oficial: 5 huecos  -  Experto: 10 huecos

|cffff9a3cObjetos de campamento|r
Cada profesión puede añadir un objeto por jugador a una hoguera: con 20, 140 y 300 de habilidad. Primero fabricas el objeto (va a tus bolsas) y luego lo usas junto a la hoguera. Todos los objetos de campamento comparten un tiempo de reutilización de 1 hora. Un rango superior de tu profesión sustituye al inferior.

|cffff9a3cConseguir los beneficios|r
Descansa 1 minuto junto a la hoguera: siéntate, usa una silla, duerme, túmbate o arrodíllate. Puedes lanzar hechizos y fabricar mientras tanto. Obtienes "%BENEFITS%" durante 1 hora - se mantiene al irte. Vuelve a sentarte para sumar objetos colocados después.

|cffff9a3cConflictos de beneficios|r
Los beneficios de campamento no se acumulan con el beneficio de clase equivalente:
%CONFLICTS%
Campfire by Felix marca en rojo un objeto de campamento cuando tienes uno de esos beneficios.

|cffff9a3cRecetas y planos|r
Rango 1 (habilidad 20): de tu instructor de profesión o de la misión "Camping 101".
Rangos 2 y 3 (140 / 300): planos que sueltan los jefes - cada página de profesión muestra qué jefe y dónde. Usa el plano para aprender la receta.

|cffff9a3cConsejos|r
  La tienda de campaña recarga la experiencia de descanso (una vez por hora) - genial mientras subes de nivel.
  El robot de reparaciones de Ingeniería repara y vende; el robot de componentes vende componentes.
  El invernadero de Herboristería cultiva hierbas a partir de semillas, el jardín de rocas genera mineral.
  En grupo, abre "Plan de grupo" antes de encender la hoguera: un objeto por jugador, sin repetir.

/cfm - abrir  -  /cfm guide  -  /cfm group  -  /cfm options]],
}

ns.LOCALES.esMX = {
    optDesc        = "Todo sobre acampar en WoW Forever en una sola ventana: qué pueden colocar tus profesiones en una fogata, qué te falta todavía, dónde cae cada plano, conflictos de beneficios y un plan de campamento para tu grupo. Se abre solo al llegar a una fogata.",
    optAutoOpen    = "Abrir la ventana al llegar a una fogata",
    optAutoClose   = "Cerrarla al alejarme (si se abrió sola)",
    optGroup       = "Compartir con mi grupo / banda lo que puedo aportar (usuarios de Campfire by Felix)",
    optMinimap     = "Mostrar el botón del minimapa",
    btnOpen        = "Abrir Campfire by Felix",
    ttLeft         = "Clic izquierdo: abrir / cerrar",
    ttRight        = "Clic derecho: opciones",
    ttDrag         = "Arrastrar: mover este botón",
    msgAutoOn      = "Se abre automáticamente en las fogatas.",
    msgAutoOff     = "Ya no se abre automáticamente.",
    msgCombat      = "No en combate - inténtalo de nuevo después.",
    msgOpenProf    = "Abre la ventana de tu profesión para fabricarlo.",
    msgHelp        = "/cfm - abrir / cerrar, /cfm guide, /cfm group, /cfm auto - activar/desactivar apertura automática, /cfm options",

    hdrCamp        = "Campamento",
    hdrProfessions = "Profesiones",
    navOverview    = "Resumen",
    navOverviewSub = "todo de un vistazo",
    navFire        = "Fogatas",
    navFireSub     = "kits, espacios, planos",
    navGroup       = "Plan de grupo",
    navGroupSub    = "quién trae qué",
    navGuide       = "Guía",
    navGuideSub    = "cómo funciona acampar",

    hdrNoFire      = "No hay ninguna fogata cerca",
    hdrFireUnknown = "Fogata cerca - pasa el mouse por encima del fuego para ver su tamaño",
    hdrFire        = "%s cerca  -  %d / %d espacios vistos",
    hdrCooldown    = "Tiempo de reutilización del campamento:",
    hdrBuff        = "Beneficio del campamento:",
    ready          = "listo",
    none           = "ninguno",

    fire_basic      = "Fogata básica",
    fire_journeyman = "Fogata de oficial",
    fire_expert     = "Fogata de experto",
    fireTier       = "%s %d  -  %d espacios",
    fireSub        = "La cocina crea la fogata. Las fogatas más grandes admiten más objetos de campamento - uno por jugador.",
    fireEffect     = "Enciende una fogata durante unos 15 minutos. Otros jugadores añaden sus objetos de campamento.",
    objTier        = "%s %d",

    stBags         = "En tus bolsas - colócalo",
    stCraft        = "Puedes fabricarlo",
    stLearn        = "Aprende la receta",
    stSkill        = "%d de habilidad más",
    stNone         = "Profesión no aprendida",
    atFire         = "Ya está en esta fogata",
    sideReady      = "%d listos",
    profSkill      = "Habilidad %d / %d",
    profNone       = "sin aprender",

    source         = "Aprender",
    srcTrainer     = "instructor de profesión o la misión \"Camping 101\"",
    srcTrainerCooking = "Instructor de cocina",
    blueprint      = "Plano",
    bpInBags       = "(en tus bolsas - ¡úsalo!)",
    reagents       = "Componentes",
    inBank         = "(banco)",
    conflictInfo   = "No se acumula con %s.",
    conflictActive = "Tienes %s - este beneficio de campamento no te funciona en este momento.",
    conflictShort  = "bloqueado",

    btnCraft       = "Fabricar",
    btnPlace       = "Colocar ya",
    btnPlaceNoFire = "Colocar (requiere fogata)",

    colObject      = "Objeto de campamento",
    colProfession  = "Profesión",
    colStatus      = "Estado",
    overviewSub    = "%d para colocar, %d para fabricar, %d recetas por aprender - haz clic en una fila para ver detalles",
    ttOpenProf     = "Clic: abrir la página de esta profesión",

    groupSolo      = "No estás en un grupo. Únete a uno: los miembros que usan Campfire by Felix aparecen aquí.",
    groupSub       = "%d miembro(s) del grupo con Campfire by Felix. Un objeto por jugador - este es el mejor reparto:",
    planReady      = "(listo)",
    planCraft      = "(fabricar primero)",
    planEmpty      = "Nadie puede aportar nada todavía - mira el Resumen para ver qué fabricar.",
    alreadyAtFire  = "Ya en la fogata:",
    groupHint      = "Los objetos con beneficios van primero porque ayudan a todos; después, las estaciones superiores. Los miembros sin el addon no aparecen.",

    guideSub       = "Breve y práctico - todo lo que necesitas saber.",
    guide = [[
|cffff9a3cLa fogata|r
La cocina crea un kit de fogata (%WOOD% + %FLINT% para la básica). Usa el kit al aire libre y la fogata arde unos 15 minutos. No puedes encender una fogata a menos de 100 metros de otra.
  Fogata básica: 3 espacios  -  Oficial: 5 espacios  -  Experto: 10 espacios

|cffff9a3cObjetos de campamento|r
Cada profesión puede añadir un objeto por jugador a una fogata: con 20, 140 y 300 de habilidad. Primero fabricas el objeto (va a tus bolsas) y luego lo usas junto a la fogata. Todos los objetos de campamento comparten un tiempo de reutilización de 1 hora. Un rango superior de tu profesión sustituye al inferior.

|cffff9a3cConseguir los beneficios|r
Descansa 1 minuto junto a la fogata: siéntate, usa una silla, duerme, acuéstate o arrodíllate. Puedes lanzar hechizos y fabricar mientras tanto. Obtienes "%BENEFITS%" durante 1 hora - se mantiene al irte. Vuelve a sentarte para sumar objetos colocados después.

|cffff9a3cConflictos de beneficios|r
Los beneficios de campamento no se acumulan con el beneficio de clase equivalente:
%CONFLICTS%
Campfire by Felix marca en rojo un objeto de campamento cuando tienes uno de esos beneficios.

|cffff9a3cRecetas y planos|r
Rango 1 (habilidad 20): de tu instructor de profesión o de la misión "Camping 101".
Rangos 2 y 3 (140 / 300): planos que sueltan los jefes - cada página de profesión muestra qué jefe y dónde. Usa el plano para aprender la receta.

|cffff9a3cConsejos|r
  La casa de campaña recarga la experiencia de descanso (una vez por hora) - ideal mientras subes de nivel.
  El robot de reparaciones de Ingeniería repara y vende; el robot de componentes vende componentes.
  El invernadero de Herboristería cultiva hierbas a partir de semillas, el jardín de rocas produce mineral.
  En grupo, abre "Plan de grupo" antes de encender la fogata: un objeto por jugador, sin repetir.

/cfm - abrir  -  /cfm guide  -  /cfm group  -  /cfm options]],
}

ns.LOCALES.itIT = {
    optDesc        = "Tutto sul campeggio di WoW Forever in un'unica finestra: cosa possono piazzare le tue professioni a un falò, cosa ti manca ancora, dove si trova ogni progetto, conflitti tra benefici e un piano del campo per il tuo gruppo. Si apre da solo quando raggiungi un falò.",
    optAutoOpen    = "Apri la finestra quando raggiungo un falò",
    optAutoClose   = "Richiudila quando mi allontano (se si è aperta da sola)",
    optGroup       = "Condividi con il gruppo / l'incursione ciò che posso portare (utenti di Campfire by Felix)",
    optMinimap     = "Mostra il pulsante della minimappa",
    btnOpen        = "Apri Campfire by Felix",
    ttLeft         = "Clic sinistro: apri / chiudi",
    ttRight        = "Clic destro: impostazioni",
    ttDrag         = "Trascina: sposta questo pulsante",
    msgAutoOn      = "Si apre automaticamente ai falò.",
    msgAutoOff     = "Non si apre più automaticamente.",
    msgCombat      = "Non in combattimento - riprova dopo.",
    msgOpenProf    = "Apri la finestra della professione per crearlo.",
    msgHelp        = "/cfm - apri / chiudi, /cfm guide, /cfm group, /cfm auto - apertura automatica sì/no, /cfm options",

    hdrCamp        = "Campo",
    hdrProfessions = "Professioni",
    navOverview    = "Panoramica",
    navOverviewSub = "tutto a colpo d'occhio",
    navFire        = "Falò",
    navFireSub     = "kit, posti, progetti",
    navGroup       = "Piano di gruppo",
    navGroupSub    = "chi porta cosa",
    navGuide       = "Guida",
    navGuideSub    = "come funziona il campeggio",

    hdrNoFire      = "Nessun falò nelle vicinanze",
    hdrFireUnknown = "Falò nelle vicinanze - passa il mouse sul fuoco per vederne la dimensione",
    hdrFire        = "%s nelle vicinanze  -  %d / %d posti visti",
    hdrCooldown    = "Tempo di recupero del campo:",
    hdrBuff        = "Beneficio del campo:",
    ready          = "pronto",
    none           = "nessuno",

    fire_basic      = "Falò base",
    fire_journeyman = "Falò da specialista",
    fire_expert     = "Falò da esperto",
    fireTier       = "%s %d  -  %d posti",
    fireSub        = "La Cucina crea il falò. I falò più grandi accolgono più oggetti da campo - uno per giocatore.",
    fireEffect     = "Accende un falò per circa 15 minuti. Gli altri giocatori vi aggiungono i loro oggetti da campo.",
    objTier        = "%s %d",

    stBags         = "Nelle borse - piazzalo",
    stCraft        = "Puoi crearlo",
    stLearn        = "Impara la ricetta",
    stSkill        = "ancora %d punti abilità",
    stNone         = "Professione non appresa",
    atFire         = "Già presente a questo falò",
    sideReady      = "%d pronti",
    profSkill      = "Abilità %d / %d",
    profNone       = "non appresa",

    source         = "Impara",
    srcTrainer     = "istruttore di professione o la missione \"Camping 101\"",
    srcTrainerCooking = "Istruttore di Cucina",
    blueprint      = "Progetto",
    bpInBags       = "(nelle tue borse - usalo!)",
    reagents       = "Reagenti",
    inBank         = "(banca)",
    conflictInfo   = "Non si cumula con %s.",
    conflictActive = "Hai %s - questo beneficio del campo per ora non ha effetto su di te.",
    conflictShort  = "bloccato",

    btnCraft       = "Crea",
    btnPlace       = "Piazza ora",
    btnPlaceNoFire = "Piazza (serve un falò)",

    colObject      = "Oggetto da campo",
    colProfession  = "Professione",
    colStatus      = "Stato",
    overviewSub    = "%d da piazzare, %d da creare, %d ricette da imparare - clicca una riga per i dettagli",
    ttOpenProf     = "Clic: apri la pagina di questa professione",

    groupSolo      = "Non sei in un gruppo. Unisciti a uno: qui compaiono i membri che usano Campfire by Felix.",
    groupSub       = "%d membro/i del gruppo con Campfire by Felix. Un oggetto per giocatore - ecco la divisione migliore:",
    planReady      = "(pronto)",
    planCraft      = "(prima crealo)",
    planEmpty      = "Nessuno può ancora portare nulla - guarda la Panoramica per sapere cosa creare.",
    alreadyAtFire  = "Già al falò:",
    groupHint      = "Prima gli oggetti con benefici, perché aiutano tutti; poi le stazioni di livello superiore. I membri senza l'addon non sono elencati.",

    guideSub       = "Breve e pratica - tutto quello che ti serve sapere.",
    guide = [[
|cffff9a3cIl falò|r
La Cucina crea un kit per falò (%WOOD% + %FLINT% per quello base). Usa il kit all'aperto e il fuoco arde per circa 15 minuti. Non puoi accendere un falò entro 100 metri da un altro.
  Falò base: 3 posti  -  Specialista: 5 posti  -  Esperto: 10 posti

|cffff9a3cOggetti da campo|r
Ogni professione può aggiungere a un falò un oggetto per giocatore: con abilità 20, 140 e 300. Prima crei l'oggetto (finisce nelle borse), poi lo usi accanto al fuoco. Tutti gli oggetti da campo condividono un tempo di recupero di 1 ora. Un livello superiore della tua professione sostituisce quello inferiore.

|cffff9a3cOttenere i benefici|r
Riposa 1 minuto accanto al fuoco: siediti, usa una sedia, dormi, sdraiati o inginocchiati. Lanciare incantesimi e creare oggetti è consentito. Ottieni "%BENEFITS%" per 1 ora - resta anche quando te ne vai. Siediti di nuovo per aggiungere gli oggetti piazzati dopo.

|cffff9a3cConflitti tra benefici|r
I benefici del campo non si cumulano con il beneficio di classe corrispondente:
%CONFLICTS%
Campfire by Felix segna in rosso un oggetto da campo quando hai addosso uno di questi benefici.

|cffff9a3cRicette e progetti|r
Livello 1 (abilità 20): dal tuo istruttore di professione o dalla missione "Camping 101".
Livelli 2 e 3 (140 / 300): progetti rilasciati dai boss - ogni pagina di professione mostra quale boss e dove. Usa il progetto per imparare la ricetta.

|cffff9a3cConsigli|r
  La tenda da campo ricarica l'esperienza da riposo (una volta all'ora) - ottima mentre sali di livello.
  Il robot riparatore dell'Ingegneria ripara e vende; il robot dei reagenti vende reagenti.
  La serra dell'Erbalismo fa crescere erbe dai semi, il giardino roccioso genera minerali.
  In gruppo, apri "Piano di gruppo" prima di accendere il fuoco: un oggetto per giocatore, niente doppioni.

/cfm - apri  -  /cfm guide  -  /cfm group  -  /cfm options]],
}

ns.LOCALES.ptBR = {
    optDesc        = "Tudo sobre acampar em WoW Forever em uma janela: o que suas profissões podem montar numa fogueira, o que ainda falta, onde cai cada projeto, conflitos de bônus e um plano de acampamento para o seu grupo. Abre sozinho quando você chega a uma fogueira.",
    optAutoOpen    = "Abrir a janela quando eu chegar a uma fogueira",
    optAutoClose   = "Fechar de novo quando eu me afastar (se tiver aberto sozinha)",
    optGroup       = "Compartilhar com meu grupo / raide o que posso levar (usuários do Campfire by Felix)",
    optMinimap     = "Mostrar o botão do minimapa",
    btnOpen        = "Abrir Campfire by Felix",
    ttLeft         = "Clique esquerdo: abrir / fechar",
    ttRight        = "Clique direito: configurações",
    ttDrag         = "Arrastar: mover este botão",
    msgAutoOn      = "Abre automaticamente em fogueiras.",
    msgAutoOff     = "Não abre mais automaticamente.",
    msgCombat      = "Não em combate - tente de novo depois.",
    msgOpenProf    = "Abra a janela da sua profissão para criá-lo.",
    msgHelp        = "/cfm - abrir / fechar, /cfm guide, /cfm group, /cfm auto - ligar/desligar abertura automática, /cfm options",

    hdrCamp        = "Acampamento",
    hdrProfessions = "Profissões",
    navOverview    = "Visão geral",
    navOverviewSub = "tudo num relance",
    navFire        = "Fogueiras",
    navFireSub     = "kits, vagas, projetos",
    navGroup       = "Plano do grupo",
    navGroupSub    = "quem leva o quê",
    navGuide       = "Guia",
    navGuideSub    = "como funciona acampar",

    hdrNoFire      = "Nenhuma fogueira por perto",
    hdrFireUnknown = "Fogueira por perto - passe o mouse sobre o fogo para ver o tamanho",
    hdrFire        = "%s por perto  -  %d / %d vagas vistas",
    hdrCooldown    = "Recarga do acampamento:",
    hdrBuff        = "Bônus do acampamento:",
    ready          = "pronto",
    none           = "nenhum",

    fire_basic      = "Fogueira básica",
    fire_journeyman = "Fogueira de artífice",
    fire_expert     = "Fogueira de especialista",
    fireTier       = "%s %d  -  %d vagas",
    fireSub        = "Culinária faz a fogueira. Fogueiras maiores comportam mais objetos de acampamento - um por jogador.",
    fireEffect     = "Acende uma fogueira por cerca de 15 minutos. Outros jogadores adicionam seus objetos de acampamento a ela.",
    objTier        = "%s %d",

    stBags         = "Nas suas bolsas - monte-o",
    stCraft        = "Você pode criar",
    stLearn        = "Aprender a receita",
    stSkill        = "faltam %d de perícia",
    stNone         = "Profissão não aprendida",
    atFire         = "Já está nesta fogueira",
    sideReady      = "%d prontos",
    profSkill      = "Perícia %d / %d",
    profNone       = "não aprendida",

    source         = "Aprender",
    srcTrainer     = "instrutor de profissão ou a missão \"Camping 101\"",
    srcTrainerCooking = "Instrutor de Culinária",
    blueprint      = "Projeto",
    bpInBags       = "(nas suas bolsas - use-o!)",
    reagents       = "Reagentes",
    inBank         = "(banco)",
    conflictInfo   = "Não acumula com %s.",
    conflictActive = "Você tem %s - este bônus do acampamento não funciona para você agora.",
    conflictShort  = "bloqueado",

    btnCraft       = "Criar",
    btnPlace       = "Montar agora",
    btnPlaceNoFire = "Montar (precisa de fogueira)",

    colObject      = "Objeto de acampamento",
    colProfession  = "Profissão",
    colStatus      = "Status",
    overviewSub    = "%d para montar, %d para criar, %d receitas para aprender - clique numa linha para ver detalhes",
    ttOpenProf     = "Clique: abrir a página desta profissão",

    groupSolo      = "Você não está em um grupo. Entre em um: membros que usam o Campfire by Felix aparecem aqui.",
    groupSub       = "%d membro(s) do grupo com Campfire by Felix. Um objeto por jogador - esta é a melhor divisão:",
    planReady      = "(pronto)",
    planCraft      = "(criar antes)",
    planEmpty      = "Ninguém pode levar nada ainda - veja na Visão geral o que criar.",
    alreadyAtFire  = "Já na fogueira:",
    groupHint      = "Objetos com bônus vêm primeiro porque ajudam todo mundo; depois as estações mais altas. Membros sem o addon não aparecem na lista.",

    guideSub       = "Curto e prático - tudo o que você precisa saber.",
    guide = [[
|cffff9a3cA fogueira|r
Culinária cria um kit de fogueira (%WOOD% + %FLINT% para a básica). Use o kit ao ar livre e a fogueira queima por cerca de 15 minutos. Não é possível acender uma fogueira a menos de 100 metros de outra.
  Fogueira básica: 3 vagas  -  Artífice: 5 vagas  -  Especialista: 10 vagas

|cffff9a3cObjetos de acampamento|r
Cada profissão pode adicionar um objeto por jogador a uma fogueira: com perícia 20, 140 e 300. Primeiro você cria o objeto (ele vai para as bolsas) e depois o usa ao lado da fogueira. Todos os objetos de acampamento compartilham uma recarga de 1 hora. Um nível maior da sua profissão substitui o menor.

|cffff9a3cComo ganhar os bônus|r
Descanse 1 minuto junto à fogueira: sente-se, use uma cadeira, durma, deite-se ou ajoelhe-se. Lançar feitiços e criar itens é permitido. Você recebe "%BENEFITS%" por 1 hora - continua ativo quando você sai. Sente-se de novo para incluir objetos montados depois.

|cffff9a3cConflitos de bônus|r
Bônus de acampamento não acumulam com o bônus de classe correspondente:
%CONFLICTS%
Campfire by Felix marca um objeto de acampamento em vermelho quando você tem um desses bônus.

|cffff9a3cReceitas e projetos|r
Nível 1 (perícia 20): com o instrutor de profissão ou pela missão "Camping 101".
Níveis 2 e 3 (140 / 300): projetos que chefes derrubam - cada página de profissão mostra qual chefe e onde. Use o projeto para aprender a receita.

|cffff9a3cDicas|r
  A barraca de acampamento recarrega a experiência de descanso (uma vez por hora) - ótima para subir de nível.
  O robô de reparos da Engenharia conserta e vende; o robô de reagentes vende reagentes.
  A estufa do Herborismo cultiva ervas a partir de sementes, o jardim de pedras gera minério.
  Em grupo, abra "Plano do grupo" antes de acender a fogueira: um objeto por jogador, sem repetir.

/cfm - abrir  -  /cfm guide  -  /cfm group  -  /cfm options]],
}

ns.LOCALES.ruRU = {
    optDesc        = "Всё о кемпинге в WoW Forever в одном окне: что твои профессии могут поставить у костра, чего ещё не хватает, где выпадает каждый чертеж, конфликты эффектов и план лагеря для группы. Открывается само, когда ты подходишь к костру.",
    optAutoOpen    = "Открывать окно, когда я подхожу к костру",
    optAutoClose   = "Закрывать его, когда я ухожу (если оно открылось само)",
    optGroup       = "Сообщать группе / рейду, что я могу принести (пользователям Campfire by Felix)",
    optMinimap     = "Показывать кнопку у миникарты",
    btnOpen        = "Открыть Campfire by Felix",
    ttLeft         = "Левый щелчок: открыть / закрыть",
    ttRight        = "Правый щелчок: настройки",
    ttDrag         = "Перетаскивание: переместить кнопку",
    msgAutoOn      = "Теперь открывается автоматически у костров.",
    msgAutoOff     = "Больше не открывается автоматически.",
    msgCombat      = "Недоступно в бою - попробуй позже.",
    msgOpenProf    = "Открой окно профессии, чтобы создать предмет.",
    msgHelp        = "/cfm - открыть / закрыть, /cfm guide, /cfm group, /cfm auto - вкл./выкл. автооткрытие, /cfm options",

    hdrCamp        = "Лагерь",
    hdrProfessions = "Профессии",
    navOverview    = "Обзор",
    navOverviewSub = "всё с одного взгляда",
    navFire        = "Костры",
    navFireSub     = "наборы, места, чертежи",
    navGroup       = "План группы",
    navGroupSub    = "кто что приносит",
    navGuide       = "Руководство",
    navGuideSub    = "как устроен кемпинг",

    hdrNoFire      = "Поблизости нет костра",
    hdrFireUnknown = "Костер поблизости - наведи курсор на огонь, чтобы узнать размер",
    hdrFire        = "%s поблизости  -  видно мест: %d / %d",
    hdrCooldown    = "Восстановление лагеря:",
    hdrBuff        = "Эффект лагеря:",
    ready          = "готово",
    none           = "нет",

    fire_basic      = "Простой костер",
    fire_journeyman = "Костер подмастерья",
    fire_expert     = "Костер умельца",
    fireTier       = "%s %d  -  мест: %d",
    fireSub        = "Костер дает кулинария. Чем больше костер, тем больше лагерных объектов - по одному на игрока.",
    fireEffect     = "Разжигает костер примерно на 15 минут. Другие игроки ставят рядом свои лагерные объекты.",
    objTier        = "%s %d",

    stBags         = "В сумках - поставь",
    stCraft        = "Можно создать",
    stLearn        = "Изучи рецепт",
    stSkill        = "нужно ещё %d навыка",
    stNone         = "Профессия не изучена",
    atFire         = "Уже у этого костра",
    sideReady      = "готово: %d",
    profSkill      = "Навык %d / %d",
    profNone       = "не изучена",

    source         = "Изучение",
    srcTrainer     = "учитель профессии или задание «Camping 101»",
    srcTrainerCooking = "Учитель кулинарии",
    blueprint      = "Чертеж",
    bpInBags       = "(в сумках - используй!)",
    reagents       = "Реагенты",
    inBank         = "(банк)",
    conflictInfo   = "Не суммируется с %s.",
    conflictActive = "На тебе %s - этот эффект лагеря сейчас на тебя не действует.",
    conflictShort  = "заблокировано",

    btnCraft       = "Создать",
    btnPlace       = "Поставить",
    btnPlaceNoFire = "Поставить (нужен костер)",

    colObject      = "Лагерный объект",
    colProfession  = "Профессия",
    colStatus      = "Статус",
    overviewSub    = "поставить: %d, создать: %d, изучить рецептов: %d - нажми на строку, чтобы увидеть подробности",
    ttOpenProf     = "Щелчок: открыть страницу профессии",

    groupSolo      = "Ты не в группе. Вступи в группу: здесь появятся участники с Campfire by Felix.",
    groupSub       = "Участников группы с Campfire by Felix: %d. Один объект на игрока - лучшее распределение:",
    planReady      = "(готово)",
    planCraft      = "(сначала создать)",
    planEmpty      = "Пока никто ничего не может принести - в обзоре видно, что создать.",
    alreadyAtFire  = "Уже у костра:",
    groupHint      = "Сначала объекты с эффектами, ведь они помогают всем; затем станции высших уровней. Участники без аддона не отображаются.",

    guideSub       = "Коротко и по делу - всё, что нужно знать.",
    guide = [[
|cffff9a3cКостер|r
Кулинария создает набор для костра (%WOOD% + %FLINT% для простого). Используй набор под открытым небом, и костер будет гореть около 15 минут. Нельзя разжечь костер ближе 100 метров от другого.
  Простой костер: 3 места  -  Подмастерье: 5 мест  -  Умелец: 10 мест

|cffff9a3cЛагерные объекты|r
Каждая профессия может добавить к костру по одному объекту на игрока: при навыке 20, 140 и 300. Сначала создай объект (он попадет в сумки), затем используй его рядом с костром. У всех лагерных объектов общее время восстановления - 1 час. Более высокий уровень твоей профессии заменяет низкий.

|cffff9a3cКак получить эффекты|r
Отдохни у костра 1 минуту: сядь, используй стул, спи, ляг или встань на колени. Произносить заклинания и создавать предметы можно. Ты получишь «%BENEFITS%» на 1 час - эффект сохраняется, когда уходишь. Сядь снова, чтобы получить объекты, поставленные позже.

|cffff9a3cКонфликты эффектов|r
Эффекты лагеря не суммируются с соответствующим классовым эффектом:
%CONFLICTS%
Campfire by Felix помечает лагерный объект красным, если на тебе такой эффект.

|cffff9a3cРецепты и чертежи|r
Уровень 1 (навык 20): у учителя профессии или за задание «Camping 101».
Уровни 2 и 3 (140 / 300): чертежи, которые выпадают из боссов - на странице каждой профессии видно, какой босс и где. Используй чертеж, чтобы изучить рецепт.

|cffff9a3cСоветы|r
  Походная палатка восполняет бонус отдыха (раз в час) - отлично при прокачке.
  Ремонтный робот инженеров чинит и продает; робот с реагентами продает реагенты.
  Теплица травников выращивает травы из семян, каменный сад создает руду.
  В группе открой «План группы» перед тем, как разжечь костер: один объект на игрока, без повторов.

/cfm - открыть  -  /cfm guide  -  /cfm group  -  /cfm options]],
}

ns.LOCALES.koKR = {
    optDesc        = "WoW Forever 캠핑의 모든 것을 한 창에서: 전문 기술로 모닥불에 설치할 수 있는 것, 아직 필요한 것, 각 설계도의 획득처, 강화 효과 충돌, 그리고 파티를 위한 캠프 계획. 모닥불에 다가가면 자동으로 열립니다.",
    optAutoOpen    = "모닥불에 다가가면 창 열기",
    optAutoClose   = "멀어지면 다시 닫기 (자동으로 열린 경우)",
    optGroup       = "내가 가져갈 수 있는 것을 파티 / 공격대와 공유 (Campfire by Felix 사용자)",
    optMinimap     = "미니맵 버튼 표시",
    btnOpen        = "Campfire by Felix 열기",
    ttLeft         = "왼쪽 클릭: 열기 / 닫기",
    ttRight        = "오른쪽 클릭: 설정",
    ttDrag         = "드래그: 버튼 이동",
    msgAutoOn      = "모닥불에서 자동으로 열립니다.",
    msgAutoOff     = "더 이상 자동으로 열리지 않습니다.",
    msgCombat      = "전투 중에는 할 수 없습니다 - 전투 후 다시 시도하세요.",
    msgOpenProf    = "제작하려면 전문 기술 창을 여세요.",
    msgHelp        = "/cfm - 열기 / 닫기, /cfm guide, /cfm group, /cfm auto - 자동 열기 켜기/끄기, /cfm options",

    hdrCamp        = "캠프",
    hdrProfessions = "전문 기술",
    navOverview    = "개요",
    navOverviewSub = "한눈에 보기",
    navFire        = "모닥불",
    navFireSub     = "도구, 자리, 설계도",
    navGroup       = "파티 계획",
    navGroupSub    = "누가 무엇을 가져오나",
    navGuide       = "가이드",
    navGuideSub    = "캠핑의 원리",

    hdrNoFire      = "근처에 모닥불 없음",
    hdrFireUnknown = "근처에 모닥불 있음 - 불에 마우스를 올리면 크기가 표시됩니다",
    hdrFire        = "근처: %s  -  확인된 자리 %d / %d",
    hdrCooldown    = "캠프 재사용 대기시간:",
    hdrBuff        = "캠프 강화 효과:",
    ready          = "준비됨",
    none           = "없음",

    fire_basic      = "기본 모닥불",
    fire_journeyman = "숙련 모닥불",
    fire_expert     = "전문 모닥불",
    fireTier       = "%s %d  -  자리 %d개",
    fireSub        = "요리로 모닥불을 만듭니다. 큰 모닥불일수록 더 많은 캠프 물품을 놓을 수 있습니다 - 플레이어당 하나.",
    fireEffect     = "약 15분 동안 모닥불을 피웁니다. 다른 플레이어가 자신의 캠프 물품을 추가합니다.",
    objTier        = "%s %d",

    stBags         = "가방에 있음 - 설치하세요",
    stCraft        = "제작 가능",
    stLearn        = "제조법 배우기",
    stSkill        = "숙련도 %d 부족",
    stNone         = "전문 기술 미습득",
    atFire         = "이미 이 모닥불에 있음",
    sideReady      = "%d개 준비됨",
    profSkill      = "숙련도 %d / %d",
    profNone       = "미습득",

    source         = "습득",
    srcTrainer     = "전문 기술 전문가 또는 \"Camping 101\" 퀘스트",
    srcTrainerCooking = "요리 전문가",
    blueprint      = "설계도",
    bpInBags       = "(가방에 있음 - 사용하세요!)",
    reagents       = "재료",
    inBank         = "(은행)",
    conflictInfo   = "%s 효과와 중첩되지 않습니다.",
    conflictActive = "%s 효과가 있어 지금은 이 캠프 강화 효과가 적용되지 않습니다.",
    conflictShort  = "차단됨",

    btnCraft       = "제작",
    btnPlace       = "지금 설치",
    btnPlaceNoFire = "설치 (모닥불 필요)",

    colObject      = "캠프 물품",
    colProfession  = "전문 기술",
    colStatus      = "상태",
    overviewSub    = "설치 가능 %d, 제작 가능 %d, 배울 제조법 %d - 행을 클릭하면 상세 정보가 표시됩니다",
    ttOpenProf     = "클릭: 이 전문 기술 페이지 열기",

    groupSolo      = "파티에 속해 있지 않습니다. 파티에 참여하면 Campfire by Felix를 쓰는 구성원이 여기에 표시됩니다.",
    groupSub       = "Campfire by Felix 사용 파티원 %d명. 플레이어당 물품 하나 - 최적의 분배:",
    planReady      = "(준비됨)",
    planCraft      = "(먼저 제작)",
    planEmpty      = "아직 아무도 가져올 수 있는 것이 없습니다 - 개요에서 무엇을 제작할지 확인하세요.",
    alreadyAtFire  = "이미 모닥불에 있음:",
    groupHint      = "강화 효과 물품은 모두에게 도움이 되므로 먼저, 그다음 높은 단계의 시설 순입니다. 애드온이 없는 구성원은 표시되지 않습니다.",

    guideSub       = "짧고 실용적으로 - 알아야 할 모든 것.",
    guide = [[
|cffff9a3c모닥불|r
요리로 모닥불 도구를 만듭니다 (기본은 %WOOD% + %FLINT%). 야외에서 도구를 사용하면 모닥불이 약 15분 동안 탑니다. 다른 모닥불 100미터 이내에서는 불을 피울 수 없습니다.
  기본 모닥불: 3자리  -  숙련: 5자리  -  전문: 10자리

|cffff9a3c캠프 물품|r
모든 전문 기술은 플레이어당 하나의 물품을 모닥불에 추가할 수 있습니다: 숙련도 20, 140, 300에서. 먼저 물품을 제작하고 (가방에 들어감) 모닥불 옆에서 사용하세요. 모든 캠프 물품은 1시간 재사용 대기시간을 공유합니다. 전문 기술의 높은 단계가 낮은 단계를 대체합니다.

|cffff9a3c강화 효과 받기|r
모닥불 옆에서 1분간 휴식하세요: 앉기, 의자 사용, 잠자기, 눕기, 무릎 꿇기. 주문 시전과 제작은 해도 됩니다. 1시간 동안 "%BENEFITS%" 효과를 받으며 - 자리를 떠나도 유지됩니다. 나중에 설치된 물품을 추가하려면 다시 앉으세요.

|cffff9a3c강화 효과 충돌|r
캠프 강화 효과는 대응하는 직업 강화 효과와 중첩되지 않습니다:
%CONFLICTS%
그런 강화 효과가 걸려 있으면 Campfire by Felix가 해당 캠프 물품을 빨간색으로 표시합니다.

|cffff9a3c제조법과 설계도|r
1단계 (숙련도 20): 전문 기술 전문가 또는 "Camping 101" 퀘스트에서.
2단계와 3단계 (140 / 300): 우두머리가 떨어뜨리는 설계도 - 각 전문 기술 페이지에 어떤 우두머리가 어디에 있는지 표시됩니다. 설계도를 사용해 제조법을 배우세요.

|cffff9a3c팁|r
  캠프 텐트는 휴식 경험치를 채워 줍니다 (1시간에 한 번) - 레벨업할 때 유용합니다.
  기계공학의 수리 로봇은 수리와 판매를 하고, 재료 로봇은 재료를 판매합니다.
  약초채집의 온실은 씨앗으로 약초를 키우고, 암석 정원에서는 광석이 생겨납니다.
  파티에서는 불을 피우기 전에 "파티 계획"을 여세요: 플레이어당 물품 하나, 중복 없이.

/cfm - 열기  -  /cfm guide  -  /cfm group  -  /cfm options]],
}

ns.LOCALES.zhCN = {
    optDesc        = "WoW Forever 野营的一切尽在一个窗口：你的专业技能能在篝火旁放置什么、还缺什么、每张图纸在哪里掉落、增益冲突，以及为你的队伍制定的营地计划。走到篝火旁时会自动打开。",
    optAutoOpen    = "走到篝火旁时打开窗口",
    optAutoClose   = "离开时再次关闭（如果是自动打开的）",
    optGroup       = "与小队 / 团队分享我能带来的物品（Campfire by Felix 用户）",
    optMinimap     = "显示小地图按钮",
    btnOpen        = "打开 Campfire by Felix",
    ttLeft         = "左键点击：打开 / 关闭",
    ttRight        = "右键点击：设置",
    ttDrag         = "拖动：移动此按钮",
    msgAutoOn      = "到达篝火时自动打开。",
    msgAutoOff     = "不再自动打开。",
    msgCombat      = "战斗中无法操作 - 请稍后再试。",
    msgOpenProf    = "打开你的专业技能窗口来制作它。",
    msgHelp        = "/cfm - 打开 / 关闭，/cfm guide，/cfm group，/cfm auto - 切换自动打开，/cfm options",

    hdrCamp        = "营地",
    hdrProfessions = "专业技能",
    navOverview    = "总览",
    navOverviewSub = "一目了然",
    navFire        = "篝火",
    navFireSub     = "工具包、位置、图纸",
    navGroup       = "队伍计划",
    navGroupSub    = "谁带什么",
    navGuide       = "指南",
    navGuideSub    = "野营如何运作",

    hdrNoFire      = "附近没有篝火",
    hdrFireUnknown = "附近有篝火 - 将鼠标悬停在火上可查看其大小",
    hdrFire        = "附近有%s  -  已发现 %d / %d 个位置",
    hdrCooldown    = "营地冷却时间：",
    hdrBuff        = "营地增益：",
    ready          = "就绪",
    none           = "无",

    fire_basic      = "基础篝火",
    fire_journeyman = "中级篝火",
    fire_expert     = "高级篝火",
    fireTier       = "%s %d  -  %d 个位置",
    fireSub        = "烹饪可以制作篝火。篝火越大，能容纳的营地物品越多 - 每名玩家一个。",
    fireEffect     = "点燃一堆篝火，持续约15分钟。其他玩家可以在旁边放置他们的营地物品。",
    objTier        = "%s %d",

    stBags         = "在背包中 - 放置它",
    stCraft        = "你可以制作",
    stLearn        = "学习配方",
    stSkill        = "还差 %d 点技能",
    stNone         = "未学习该专业",
    atFire         = "已在此篝火旁",
    sideReady      = "%d 个就绪",
    profSkill      = "技能 %d / %d",
    profNone       = "未学习",

    source         = "学习",
    srcTrainer     = "专业训练师或任务“Camping 101”",
    srcTrainerCooking = "烹饪训练师",
    blueprint      = "图纸",
    bpInBags       = "（在你的背包中 - 快使用！）",
    reagents       = "材料",
    inBank         = "（银行）",
    conflictInfo   = "无法与%s叠加。",
    conflictActive = "你身上有%s - 此营地增益目前对你无效。",
    conflictShort  = "受阻",

    btnCraft       = "制作",
    btnPlace       = "立即放置",
    btnPlaceNoFire = "放置（需要篝火）",

    colObject      = "营地物品",
    colProfession  = "专业",
    colStatus      = "状态",
    overviewSub    = "%d 个可放置，%d 个可制作，%d 个配方待学习 - 点击一行查看详情",
    ttOpenProf     = "点击：打开此专业的页面",

    groupSolo      = "你不在队伍中。加入一个队伍：使用 Campfire by Felix 的成员会显示在这里。",
    groupSub       = "%d 名队伍成员使用 Campfire by Felix。每名玩家一个物品 - 最佳分配如下：",
    planReady      = "（就绪）",
    planCraft      = "（先制作）",
    planEmpty      = "还没有人能带来任何物品 - 在总览中查看需要制作什么。",
    alreadyAtFire  = "已在篝火旁：",
    groupHint      = "增益物品优先，因为它们对所有人都有帮助；其次是更高级的设施。未安装插件的成员不会列出。",

    guideSub       = "简明实用 - 你需要知道的一切。",
    guide = [[
|cffff9a3c篝火|r
烹饪可以制作篝火工具包（基础篝火需要 %WOOD% + %FLINT%）。在户外使用工具包，篝火会燃烧约15分钟。在另一堆篝火100码范围内无法点火。
  基础篝火：3 个位置  -  中级：5 个位置  -  高级：10 个位置

|cffff9a3c营地物品|r
每个专业都可以为篝火添加每名玩家一个物品：技能达到20、140和300时。先制作物品（会放进背包），然后在篝火旁使用它。所有营地物品共享1小时冷却时间。更高等级的专业物品会替换较低等级的。

|cffff9a3c获得增益|r
在篝火旁休息1分钟：坐下、使用椅子、睡觉、躺下或跪下。期间可以施法和制作。你会获得“%BENEFITS%”，持续1小时 - 离开后依然保留。再次坐下即可获得之后放置的物品效果。

|cffff9a3c增益冲突|r
营地增益无法与对应的职业增益叠加：
%CONFLICTS%
当你身上有这类增益时，Campfire by Felix 会将对应的营地物品标为红色。

|cffff9a3c配方与图纸|r
第1级（技能20）：来自专业训练师或任务“Camping 101”。
第2级和第3级（140 / 300）：由首领掉落的图纸 - 每个专业页面都会显示是哪个首领以及在哪里。使用图纸即可学会配方。

|cffff9a3c小贴士|r
  营地帐篷会补充休息经验（每小时一次） - 升级时非常实用。
  工程学的修理机器人可以修理和出售物品；材料机器人出售材料。
  草药学的温室可以用种子种出草药，岩石花园会生成矿石。
  组队时，点火前先打开“队伍计划”：每名玩家一个物品，避免重复。

/cfm - 打开  -  /cfm guide  -  /cfm group  -  /cfm options]],
}

ns.LOCALES.zhTW = {
    optDesc        = "WoW Forever 露營的一切都在一個視窗裡：你的專業技能能在營火旁放置什麼、還缺什麼、每張設計圖從哪裡掉落、增益衝突，以及為你的隊伍規劃的營地計畫。走到營火旁時會自動開啟。",
    optAutoOpen    = "走到營火旁時開啟視窗",
    optAutoClose   = "離開時再次關閉（如果是自動開啟的）",
    optGroup       = "與隊伍 / 團隊分享我能帶來的物品（Campfire by Felix 使用者）",
    optMinimap     = "顯示小地圖按鈕",
    btnOpen        = "開啟 Campfire by Felix",
    ttLeft         = "左鍵點擊：開啟 / 關閉",
    ttRight        = "右鍵點擊：設定",
    ttDrag         = "拖曳：移動此按鈕",
    msgAutoOn      = "到達營火時自動開啟。",
    msgAutoOff     = "不再自動開啟。",
    msgCombat      = "戰鬥中無法操作 - 請稍後再試。",
    msgOpenProf    = "開啟你的專業技能視窗來製作它。",
    msgHelp        = "/cfm - 開啟 / 關閉，/cfm guide，/cfm group，/cfm auto - 切換自動開啟，/cfm options",

    hdrCamp        = "營地",
    hdrProfessions = "專業技能",
    navOverview    = "總覽",
    navOverviewSub = "一目了然",
    navFire        = "營火",
    navFireSub     = "工具包、位置、設計圖",
    navGroup       = "隊伍計畫",
    navGroupSub    = "誰帶什麼",
    navGuide       = "指南",
    navGuideSub    = "露營如何運作",

    hdrNoFire      = "附近沒有營火",
    hdrFireUnknown = "附近有營火 - 將滑鼠游標停在火上可查看大小",
    hdrFire        = "附近有%s  -  已發現 %d / %d 個位置",
    hdrCooldown    = "營地冷卻時間：",
    hdrBuff        = "營地增益：",
    ready          = "就緒",
    none           = "無",

    fire_basic      = "基礎營火",
    fire_journeyman = "熟手營火",
    fire_expert     = "專家營火",
    fireTier       = "%s %d  -  %d 個位置",
    fireSub        = "烹飪可以製作營火。營火越大，能容納的營地物品越多 - 每名玩家一個。",
    fireEffect     = "點燃營火，持續約15分鐘。其他玩家可以在旁邊放置他們的營地物品。",
    objTier        = "%s %d",

    stBags         = "在背包中 - 放置它",
    stCraft        = "你可以製作",
    stLearn        = "學習配方",
    stSkill        = "還差 %d 點技能",
    stNone         = "未學習該專業",
    atFire         = "已在此營火旁",
    sideReady      = "%d 個就緒",
    profSkill      = "技能 %d / %d",
    profNone       = "未學習",

    source         = "學習",
    srcTrainer     = "專業技能訓練師或任務「Camping 101」",
    srcTrainerCooking = "烹飪訓練師",
    blueprint      = "設計圖",
    bpInBags       = "（在你的背包中 - 快使用！）",
    reagents       = "材料",
    inBank         = "（銀行）",
    conflictInfo   = "無法與%s疊加。",
    conflictActive = "你身上有%s - 此營地增益目前對你無效。",
    conflictShort  = "受阻",

    btnCraft       = "製作",
    btnPlace       = "立即放置",
    btnPlaceNoFire = "放置（需要營火）",

    colObject      = "營地物品",
    colProfession  = "專業",
    colStatus      = "狀態",
    overviewSub    = "%d 個可放置，%d 個可製作，%d 個配方待學習 - 點擊一列查看詳情",
    ttOpenProf     = "點擊：開啟此專業的頁面",

    groupSolo      = "你不在隊伍中。加入一個隊伍：使用 Campfire by Felix 的成員會顯示在這裡。",
    groupSub       = "%d 名隊伍成員使用 Campfire by Felix。每名玩家一個物品 - 最佳分配如下：",
    planReady      = "（就緒）",
    planCraft      = "（先製作）",
    planEmpty      = "還沒有人能帶來任何物品 - 在總覽中查看需要製作什麼。",
    alreadyAtFire  = "已在營火旁：",
    groupHint      = "增益物品優先，因為它們對所有人都有幫助；其次是更高級的設施。未安裝插件的成員不會列出。",

    guideSub       = "簡明實用 - 你需要知道的一切。",
    guide = [[
|cffff9a3c營火|r
烹飪可以製作營火工具包（基礎營火需要 %WOOD% + %FLINT%）。在戶外使用工具包，營火會燃燒約15分鐘。在另一堆營火100碼範圍內無法生火。
  基礎營火：3 個位置  -  熟手：5 個位置  -  專家：10 個位置

|cffff9a3c營地物品|r
每個專業都可以為營火添加每名玩家一個物品：技能達到20、140和300時。先製作物品（會放進背包），然後在營火旁使用它。所有營地物品共用1小時冷卻時間。更高等級的專業物品會取代較低等級的。

|cffff9a3c獲得增益|r
在營火旁休息1分鐘：坐下、使用椅子、睡覺、躺下或跪下。期間可以施法和製作。你會獲得「%BENEFITS%」，持續1小時 - 離開後依然保留。再次坐下即可獲得之後放置的物品效果。

|cffff9a3c增益衝突|r
營地增益無法與對應的職業增益疊加：
%CONFLICTS%
當你身上有這類增益時，Campfire by Felix 會將對應的營地物品標為紅色。

|cffff9a3c配方與設計圖|r
第1級（技能20）：來自專業技能訓練師或任務「Camping 101」。
第2級和第3級（140 / 300）：由首領掉落的設計圖 - 每個專業頁面都會顯示是哪個首領以及在哪裡。使用設計圖即可學會配方。

|cffff9a3c小提示|r
  營地帳篷會補充休息經驗（每小時一次） - 升級時非常實用。
  工程學的修理機器人可以修理和出售物品；材料機器人出售材料。
  草藥學的溫室可以用種子種出草藥，岩石花園會生成礦石。
  組隊時，生火前先開啟「隊伍計畫」：每名玩家一個物品，避免重複。

/cfm - 開啟  -  /cfm guide  -  /cfm group  -  /cfm options]],
}

ns.ApplyLocale()
