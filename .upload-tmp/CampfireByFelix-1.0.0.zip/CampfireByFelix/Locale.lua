--=====================================================================
--  Campfire by Felix - Locale
--  Only the addon's own words live here. Object, profession, blueprint,
--  dungeon and effect texts come from the game client itself, so they
--  are always in your client's language.
--  English is the base; any missing translation falls back to it.
--=====================================================================

local _, ns = ...

local enUS = {
    title          = "Campfire by Felix",
    optDesc        = "Everything about WoW Forever camping in one window: what your professions can place at a campfire, what you still need, where every blueprint drops, buff conflicts and a camp plan for your group. Opens by itself when you reach a fire.",
    optAutoOpen    = "Open the window when I reach a campfire",
    optAutoClose   = "Close it again when I walk away (if it opened by itself)",
    optGroup       = "Share what I can bring with my party / raid (Campfire by Felix users)",
    optMinimap     = "Show the minimap button",
    btnOpen        = "Open Campfire by Felix",
    ttLeft         = "Left-click: open / close",
    ttRight        = "Right-click: settings",
    ttDrag         = "Drag: move this button",
    msgAutoOn      = "Opens automatically at campfires.",
    msgAutoOff     = "No longer opens automatically.",
    msgCombat      = "Not in combat - try again afterwards.",
    msgOpenProf    = "Open your profession window to craft it.",
    msgHelp        = "/cfm - open / close, /cfm guide, /cfm group, /cfm auto - toggle auto-open, /cfm options",

    hdrCamp        = "Camp",
    hdrProfessions = "Professions",
    navOverview    = "Overview",
    navOverviewSub = "everything at a glance",
    navFire        = "Campfires",
    navFireSub     = "kits, slots, blueprints",
    navGroup       = "Group plan",
    navGroupSub    = "who brings what",
    navGuide       = "Guide",
    navGuideSub    = "how camping works",

    hdrNoFire      = "No campfire nearby",
    hdrFireUnknown = "Campfire nearby - hover the fire to see its size",
    hdrFire        = "%s nearby  -  %d / %d slots seen",
    hdrCooldown    = "Camp cooldown:",
    hdrBuff        = "Camp buff:",
    ready          = "ready",
    none           = "none",

    fire_basic      = "Basic Campfire",
    fire_journeyman = "Journeyman Campfire",
    fire_expert     = "Expert Campfire",
    fireTier       = "%s %d  -  %d slots",
    fireSub        = "Cooking makes the fire. Bigger fires hold more camp objects - one per player.",
    fireEffect     = "Lights a campfire for about 15 minutes. Other players add their camp objects to it.",
    objTier        = "%s %d",

    stBags         = "In your bags - place it",
    stCraft        = "You can craft it",
    stLearn        = "Learn the recipe",
    stSkill        = "%d more skill",
    stNone         = "Profession not learned",
    atFire         = "Already at this fire",
    sideReady      = "%d ready",
    profSkill      = "Skill %d / %d",
    profNone       = "not learned",

    source         = "Learn",
    srcTrainer     = "profession trainer or the quest \"Camping 101\"",
    srcTrainerCooking = "Cooking trainer",
    blueprint      = "Blueprint",
    bpInBags       = "(in your bags - use it!)",
    reagents       = "Reagents",
    inBank         = "(bank)",
    conflictInfo   = "Does not stack with %s.",
    conflictActive = "You have %s - this camp buff will not work for you right now.",
    conflictShort  = "blocked",

    btnCraft       = "Craft",
    btnPlace       = "Place now",
    btnPlaceNoFire = "Place (needs a fire)",

    colObject      = "Camp object",
    colProfession  = "Profession",
    colStatus      = "Status",
    overviewSub    = "%d to place, %d to craft, %d recipes to learn - click a row for details",
    ttOpenProf     = "Click: open this profession's page",

    groupSolo      = "You are not in a group. Join one: members running Campfire by Felix show up here.",
    groupSub       = "%d group member(s) with Campfire by Felix. One object per player - here is the best split:",
    planReady      = "(ready)",
    planCraft      = "(craft first)",
    planEmpty      = "Nobody can bring anything yet - see the Overview for what to craft.",
    alreadyAtFire  = "Already at the fire:",
    groupHint      = "Buff objects come first because they help everyone; higher stations after that. Members without the addon are not listed.",

    guideSub       = "Short and practical - everything you need to know.",
    guide = [[
|cffff9a3cThe campfire|r
Cooking makes a campfire kit (%WOOD% + %FLINT% for the basic one). Use the kit outdoors and the fire burns for about 15 minutes. You cannot light a fire within 100 yards of another one.
  Basic Campfire: 3 slots  -  Journeyman: 5 slots  -  Expert: 10 slots

|cffff9a3cCamp objects|r
Every profession can add one object per player to a fire: at skill 20, 140 and 300. You craft the object first (it goes into your bags), then use it next to the fire. All camp objects share a 1-hour cooldown. A higher tier of your profession replaces the lower one.

|cffff9a3cGetting the buffs|r
Rest by the fire for 1 minute: sit, use a chair, sleep, lie down or kneel. Casting and crafting are allowed. You get "%BENEFITS%" for 1 hour - it stays when you leave. Sit again to add objects placed later.

|cffff9a3cBuff conflicts|r
Camp buffs do not stack with the matching class buff:
%CONFLICTS%
Campfire by Felix marks a camp object red when such a buff is on you.

|cffff9a3cRecipes and blueprints|r
Tier 1 (skill 20): from your profession trainer or the quest "Camping 101".
Tier 2 and 3 (140 / 300): blueprints dropped by bosses - every profession page shows which boss and where. Use the blueprint to learn the recipe.

|cffff9a3cTips|r
  The Camp Tent tops up rested XP (once per hour) - great while leveling.
  Engineering's Repair Bot repairs and sells; the Reagent Bot sells reagents.
  Herbalism's Greenhouse grows herbs from seeds, the Rock Garden spawns ore.
  In a group, open "Group plan" before you light the fire: one object per player, no doubles.

/cfm - open  -  /cfm guide  -  /cfm group  -  /cfm options]],
}

local deDE = {
    optDesc        = "Alles zum Camping in WoW Forever in einem Fenster: was deine Berufe am Lagerfeuer aufstellen können, was dir noch fehlt, wo jeder Bauplan droppt, Buff-Konflikte und ein Lagerplan für deine Gruppe. Öffnet sich von selbst, wenn du an ein Feuer kommst.",
    optAutoOpen    = "Fenster öffnen, wenn ich an ein Lagerfeuer komme",
    optAutoClose   = "Wieder schließen, wenn ich weggehe (falls es sich selbst geöffnet hat)",
    optGroup       = "Mit Gruppe / Schlachtzug teilen, was ich mitbringen kann (Nutzer von Campfire by Felix)",
    optMinimap     = "Minimap-Knopf anzeigen",
    btnOpen        = "Campfire by Felix öffnen",
    ttLeft         = "Linksklick: öffnen / schließen",
    ttRight        = "Rechtsklick: Einstellungen",
    ttDrag         = "Ziehen: Knopf verschieben",
    msgAutoOn      = "Öffnet sich jetzt automatisch an Lagerfeuern.",
    msgAutoOff     = "Öffnet sich nicht mehr automatisch.",
    msgCombat      = "Nicht im Kampf - danach noch einmal versuchen.",
    msgOpenProf    = "Öffne dein Berufsfenster, um es herzustellen.",
    msgHelp        = "/cfm - öffnen / schließen, /cfm guide, /cfm group, /cfm auto - automatisch öffnen an/aus, /cfm options",

    hdrCamp        = "Lager",
    hdrProfessions = "Berufe",
    navOverview    = "Übersicht",
    navOverviewSub = "alles auf einen Blick",
    navFire        = "Lagerfeuer",
    navFireSub     = "Sets, Plätze, Baupläne",
    navGroup       = "Gruppenplan",
    navGroupSub    = "wer bringt was",
    navGuide       = "Guide",
    navGuideSub    = "so funktioniert Camping",

    hdrNoFire      = "Kein Lagerfeuer in der Nähe",
    hdrFireUnknown = "Lagerfeuer in der Nähe - Maus über das Feuer zeigt die Größe",
    hdrFire        = "%s in der Nähe  -  %d / %d Plätze gesehen",
    hdrCooldown    = "Lager-Abklingzeit:",
    hdrBuff        = "Lager-Buff:",
    ready          = "bereit",
    none           = "keiner",

    fire_basic      = "Einfaches Lagerfeuer",
    fire_journeyman = "Gesellen-Lagerfeuer",
    fire_expert     = "Experten-Lagerfeuer",
    fireTier       = "%s %d  -  %d Plätze",
    fireSub        = "Kochkunst macht das Feuer. Größere Feuer fassen mehr Lagerobjekte - eins pro Spieler.",
    fireEffect     = "Entzündet ein Lagerfeuer für etwa 15 Minuten. Andere Spieler stellen ihre Lagerobjekte dazu.",

    place_lordaeron = "Ruinen von Lordaeron (Tirisfal)",
    place_wetlands  = "Ausgrabungsstätte (Sumpfland)",
    place_wetlands2 = "Sumpfland",
    place_dalaran   = "Dalaran (Alteracgebirge)",

    stBags         = "In den Taschen - aufstellen",
    stCraft        = "Kannst du herstellen",
    stLearn        = "Rezept lernen",
    stSkill        = "noch %d Skill",
    stNone         = "Beruf nicht erlernt",
    atFire         = "Steht schon an diesem Feuer",
    sideReady      = "%d bereit",
    profSkill      = "Skill %d / %d",
    profNone       = "nicht erlernt",

    source         = "Lernen",
    srcTrainer     = "Berufslehrer oder Quest „Camping 101“",
    srcTrainerCooking = "Kochkunstlehrer",
    blueprint      = "Bauplan",
    bpInBags       = "(in deinen Taschen - benutzen!)",
    reagents       = "Material",
    inBank         = "(Bank)",
    conflictInfo   = "Stapelt nicht mit %s.",
    conflictActive = "Du hast %s - dieser Lager-Buff wirkt gerade nicht bei dir.",
    conflictShort  = "blockiert",

    btnCraft       = "Herstellen",
    btnPlace       = "Jetzt aufstellen",
    btnPlaceNoFire = "Aufstellen (Feuer nötig)",

    colObject      = "Lagerobjekt",
    colProfession  = "Beruf",
    colStatus      = "Status",
    overviewSub    = "%d aufstellbar, %d herstellbar, %d Rezepte zu lernen - Zeile anklicken für Details",
    ttOpenProf     = "Klick: Seite dieses Berufs öffnen",

    groupSolo      = "Du bist in keiner Gruppe. Tritt einer bei: Mitglieder mit Campfire by Felix erscheinen hier.",
    groupSub       = "%d Gruppenmitglied(er) mit Campfire by Felix. Ein Objekt pro Spieler - die beste Aufteilung:",
    planReady      = "(bereit)",
    planCraft      = "(erst herstellen)",
    planEmpty      = "Noch kann niemand etwas mitbringen - in der Übersicht siehst du, was du herstellen kannst.",
    alreadyAtFire  = "Steht schon am Feuer:",
    groupHint      = "Buff-Objekte zuerst, weil sie allen helfen; danach die höheren Stationen. Mitglieder ohne das Addon fehlen in der Liste.",

    guideSub       = "Kurz und praktisch - alles, was du wissen musst.",
    guide = [[
|cffff9a3cDas Lagerfeuer|r
Kochkunst stellt ein Lagerfeuer-Set her (%WOOD% + %FLINT% für das einfache). Benutze das Set im Freien, dann brennt das Feuer etwa 15 Minuten. Im Umkreis von 100 Metern um ein anderes Feuer geht das nicht.
  Einfaches Lagerfeuer: 3 Plätze  -  Geselle: 5 Plätze  -  Experte: 10 Plätze

|cffff9a3cLagerobjekte|r
Jeder Beruf kann pro Spieler ein Objekt an ein Feuer stellen: ab Skill 20, 140 und 300. Du stellst das Objekt zuerst her (es landet in deinen Taschen) und benutzt es dann neben dem Feuer. Alle Lagerobjekte teilen sich 1 Stunde Abklingzeit. Eine höhere Stufe deines Berufs ersetzt die niedrigere.

|cffff9a3cDie Buffs bekommen|r
Ruh dich 1 Minute am Feuer aus: sitzen, Stuhl, schlafen, hinlegen oder knien. Zaubern und Herstellen sind dabei erlaubt. Du bekommst „%BENEFITS%“ für 1 Stunde - sie bleiben, wenn du gehst. Setz dich erneut hin, um später aufgestellte Objekte mitzunehmen.

|cffff9a3cBuff-Konflikte|r
Lager-Buffs stapeln nicht mit dem passenden Klassenbuff:
%CONFLICTS%
Campfire by Felix färbt ein Lagerobjekt rot, wenn so ein Buff auf dir liegt.

|cffff9a3cRezepte und Baupläne|r
Stufe 1 (Skill 20): beim Berufslehrer oder über die Quest „Camping 101“.
Stufe 2 und 3 (140 / 300): Baupläne, die Bosse droppen - jede Berufsseite zeigt welcher Boss und wo. Benutze den Bauplan, um das Rezept zu lernen.

|cffff9a3cTipps|r
  Das Lagerzelt füllt Erholungs-EP auf (einmal pro Stunde) - ideal beim Leveln.
  Der Reparaturbot der Ingenieure repariert und verkauft; der Reagenzienbot verkauft Reagenzien.
  Das Gewächshaus der Kräuterkunde zieht Kräuter aus Samen, der Steingarten lässt Erz wachsen.
  In der Gruppe vor dem Feuer den „Gruppenplan“ öffnen: ein Objekt pro Spieler, nichts doppelt.

/cfm - öffnen  -  /cfm guide  -  /cfm group  -  /cfm options]],
}

local tables = { deDE = deDE }
ns.LOCALES = tables      -- other languages are added in Locale_*.lua

local L = setmetatable({}, { __index = enUS })
ns.L = L
ns.enUS = enUS

function ns.ApplyLocale()
    local t = tables[GetLocale and GetLocale() or "enUS"]
    if t then for k, v in pairs(t) do rawset(L, k, v) end end
end
ns.ApplyLocale()
