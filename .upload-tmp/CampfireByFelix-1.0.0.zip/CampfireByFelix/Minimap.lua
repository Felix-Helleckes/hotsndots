--=====================================================================
--  Campfire by Felix - Minimap button
--  Uses LibDBIcon when another addon already loaded it (so button
--  collectors like Leatrix Plus see it), otherwise draws its own button
--  with the same geometry. Nothing is shipped or required.
--    Left click  = camp window
--    Right click = settings
--    Drag        = move
--=====================================================================

local _, ns = ...
local L = ns.L
local ICON = ns.ICON

local button, ldbIcon

local function OnClick(_, mouseButton)
    if mouseButton == "RightButton" then
        ns.OpenOptions()
    else
        ns.Window_Toggle()
    end
end

local function FillTooltip(tt)
    tt:AddLine(ns.BRAND)
    tt:AddLine(L.ttLeft, 1, 1, 1)
    tt:AddLine(L.ttRight, 1, 1, 1)
    tt:AddLine(L.ttDrag, 1, 1, 1)
end

local function UpdatePosition()
    if not button then return end
    local angle = math.rad(ns.db.minimap.angle or 200)
    local w = (Minimap:GetWidth() / 2) + 5
    local h = (Minimap:GetHeight() / 2) + 5
    button:ClearAllPoints()
    button:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * w, math.sin(angle) * h)
end

local function OnDragUpdate()
    local mx, my = Minimap:GetCenter()
    local scale = Minimap:GetEffectiveScale()
    local cx, cy = GetCursorPosition()
    cx, cy = cx / scale, cy / scale
    ns.db.minimap.angle = math.deg(math.atan2(cy - my, cx - mx))
    UpdatePosition()
end

function ns.Minimap_UpdateShown()
    if ldbIcon then
        if ns.db.minimap.hide then ldbIcon:Hide(ns.name) else ldbIcon:Show(ns.name) end
    elseif button then
        if ns.db.minimap.hide then button:Hide() else button:Show() end
    end
end

local function TryLibDBIcon()
    if not LibStub then return false end
    local LDB = LibStub:GetLibrary("LibDataBroker-1.1", true)
    local icon = LibStub:GetLibrary("LibDBIcon-1.0", true)
    if not (LDB and icon) then return false end
    local obj = LDB:NewDataObject(ns.name, {
        type = "launcher",
        text = ns.name,
        icon = ICON,
        OnClick = OnClick,
        OnTooltipShow = FillTooltip,
    })
    if not obj then return false end
    icon:Register(ns.name, obj, ns.db.minimap)
    ldbIcon = icon
    return true
end

function ns.Minimap_Init()
    if not TryLibDBIcon() then
        button = CreateFrame("Button", "CampfireByFelixMinimapButton", Minimap)
        button:SetFrameStrata("MEDIUM")
        button:SetFrameLevel(8)
        button:SetSize(31, 31)
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        button:RegisterForDrag("LeftButton")
        button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

        local overlay = button:CreateTexture(nil, "OVERLAY")
        overlay:SetSize(53, 53)
        overlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
        overlay:SetPoint("TOPLEFT")

        local bg = button:CreateTexture(nil, "BACKGROUND")
        bg:SetSize(20, 20)
        bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
        bg:SetPoint("TOPLEFT", 7, -5)

        local icon = button:CreateTexture(nil, "ARTWORK")
        icon:SetSize(17, 17)
        icon:SetTexture(ICON)
        icon:SetTexCoord(0.05, 0.95, 0.05, 0.95)
        icon:SetPoint("TOPLEFT", 7, -6)

        button:SetScript("OnClick", OnClick)
        button:SetScript("OnDragStart", function(self) self:SetScript("OnUpdate", OnDragUpdate) end)
        button:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
        button:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_LEFT")
            FillTooltip(GameTooltip)
            GameTooltip:Show()
        end)
        button:SetScript("OnLeave", function() GameTooltip:Hide() end)
        UpdatePosition()
    end
    ns.Minimap_UpdateShown()
end

-- Addon compartment (the icon menu next to the minimap), wired in the .toc
function CampfireByFelix_OnCompartmentClick(_, mouseButton)
    OnClick(nil, mouseButton)
end

function CampfireByFelix_OnCompartmentEnter(_, menuButtonFrame)
    GameTooltip:SetOwner(menuButtonFrame, "ANCHOR_LEFT")
    FillTooltip(GameTooltip)
    GameTooltip:Show()
end

function CampfireByFelix_OnCompartmentLeave()
    GameTooltip:Hide()
end
