# Changelog

## 1.0.0

- First release: camp window that opens at every campfire, all 35 camp objects and 3 campfire kits, status per object, one-click placing, reagents (bags and bank), recipe and blueprint sources, buff conflicts, group plan over addon messages, camp cooldown and Camp Benefits timer, guide, options page, minimap button. All 11 client languages.
