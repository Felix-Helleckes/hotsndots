--=====================================================================
--  Campfire by Felix - Options (one page under Options > AddOns)
--=====================================================================

local _, ns = ...
local L = ns.L

local panel, category
local checks = {}

local function NewCheck(parent, anchor, label, get, set)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -8)
    local text = cb.Text or cb.text or cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    text:ClearAllPoints()
    text:SetPoint("LEFT", cb, "RIGHT", 4, 1)
    text:SetFontObject("GameFontHighlight")
    text:SetText(label)
    cb:SetScript("OnClick", function(self) set(self:GetChecked() and true or false) end)
    cb.Refresh = function(self) self:SetChecked(get()) end
    checks[#checks + 1] = cb
    return cb
end

function ns.Options_Refresh()
    for _, cb in ipairs(checks) do cb:Refresh() end
end

function ns.Options_Init()
    panel = CreateFrame("Frame")
    panel.name = L.title

    local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText(ns.BRAND)

    local desc = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    desc:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
    desc:SetPoint("RIGHT", panel, "RIGHT", -16, 0)
    desc:SetJustifyH("LEFT")
    desc:SetText(L.optDesc)

    local c1 = NewCheck(panel, desc, L.optAutoOpen,
        function() return ns.db.autoOpen end,
        function(v) ns.db.autoOpen = v end)
    local c2 = NewCheck(panel, c1, L.optAutoClose,
        function() return ns.db.autoClose end,
        function(v) ns.db.autoClose = v end)
    local c2b = NewCheck(panel, c2, L.optGroup,
        function() return ns.db.groupSync end,
        function(v) ns.db.groupSync = v; if v and ns.Group_Broadcast then ns.Group_Broadcast(true) end end)
    local c3 = NewCheck(panel, c2b, L.optMinimap,
        function() return not ns.db.minimap.hide end,
        function(v) ns.db.minimap.hide = not v; ns.Minimap_UpdateShown() end)

    local open = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    open:SetSize(200, 24)
    open:SetPoint("TOPLEFT", c3, "BOTTOMLEFT", 4, -14)
    open:SetText(L.btnOpen)
    open:SetScript("OnClick", function() ns.Window_Show() end)

    local help = panel:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
    help:SetPoint("TOPLEFT", open, "BOTTOMLEFT", -4, -14)
    help:SetPoint("RIGHT", panel, "RIGHT", -16, 0)
    help:SetJustifyH("LEFT")
    help:SetText(L.msgHelp)

    panel:SetScript("OnShow", ns.Options_Refresh)

    if Settings and Settings.RegisterCanvasLayoutCategory then
        category = Settings.RegisterCanvasLayoutCategory(panel, L.title)
        Settings.RegisterAddOnCategory(category)
    elseif InterfaceOptions_AddCategory then
        InterfaceOptions_AddCategory(panel)
    end
end

function ns.OpenOptions()
    if category and Settings and Settings.OpenToCategory then
        Settings.OpenToCategory(category:GetID())
    elseif InterfaceOptionsFrame_OpenToCategory and panel then
        InterfaceOptionsFrame_OpenToCategory(panel)
    end
end
