--=====================================================================
--  Campfire by Felix - Group
--  Party and raid members running the addon tell each other what they
--  carry and what they can craft, so the camp can be planned before
--  anyone lights a fire. Tiny addon messages, only out of combat and
--  only when something changed.
--=====================================================================

local _, ns = ...

local PREFIX = "CampfireFelix"
ns.group = {}          -- name -> { bags = {key=true}, craft = {key=true}, t = time }

local lastSent, lastPayload = 0, nil

local function Channel()
    if not IsInGroup or not IsInGroup() then return nil end
    if LE_PARTY_CATEGORY_INSTANCE and IsInGroup(LE_PARTY_CATEGORY_INSTANCE)
        and not IsInGroup(LE_PARTY_CATEGORY_HOME) then
        return "INSTANCE_CHAT"
    end
    if IsInRaid and IsInRaid() then return "RAID" end
    return "PARTY"
end

local function Send(text)
    local ch = Channel()
    if not ch then return end
    if InCombatLockdown and InCombatLockdown() then return end
    local send = (C_ChatInfo and C_ChatInfo.SendAddonMessage) or SendAddonMessage
    if send then pcall(send, PREFIX, text, ch) end
end

local function Encode()
    local bags, craft = {}, {}
    for i, obj in ipairs(ns.OBJECTS) do
        local st = ns.Status(obj)
        if st == "bags" then bags[#bags + 1] = i
        elseif st == "craft" then craft[#craft + 1] = i end
    end
    return "H1|" .. table.concat(bags, ",") .. "|" .. table.concat(craft, ",")
end

local function Decode(list)
    local t = {}
    for n in (list or ""):gmatch("%d+") do
        local obj = ns.OBJECTS[tonumber(n)]
        if obj then t[obj.key] = true end
    end
    return t
end

function ns.Group_Broadcast(force)
    if not ns.db or not ns.db.groupSync or not Channel() then return end
    local payload = Encode()
    local now = GetTime()
    if not force and payload == lastPayload and now - lastSent < 60 then return end
    if not force and now - lastSent < 5 then
        if C_Timer and C_Timer.After and not ns.sendQueued then
            ns.sendQueued = true
            C_Timer.After(5, function() ns.sendQueued = false; ns.Group_Broadcast() end)
        end
        return
    end
    lastSent, lastPayload = now, payload
    Send(payload)
end

local function Short(name)
    if not name or ns.Secret(name) then return nil end
    return (name:gsub("%-.*$", ""))
end

local function Prune()
    if not (IsInGroup and IsInGroup()) then wipe(ns.group); return end
    local present = {}
    local n = GetNumGroupMembers and GetNumGroupMembers() or 0
    local unit = (IsInRaid and IsInRaid()) and "raid" or "party"
    for i = 1, n do
        local name = UnitName and UnitName(unit .. i)
        if name and not ns.Secret(name) then present[name] = true end
    end
    for name in pairs(ns.group) do
        if not present[name] then ns.group[name] = nil end
    end
end

function ns.Group_Init()
    if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
        C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
    elseif RegisterAddonMessagePrefix then
        RegisterAddonMessagePrefix(PREFIX)
    end
    local f = CreateFrame("Frame")
    ns.SafeRegister(f, "CHAT_MSG_ADDON")
    ns.SafeRegister(f, "GROUP_ROSTER_UPDATE")
    f:SetScript("OnEvent", function(_, event, prefix, text, _, sender)
        if event == "GROUP_ROSTER_UPDATE" then
            Prune()
            if Channel() then Send("Q1"); ns.Group_Broadcast(true) end
            if ns.Window_Refresh then ns.Window_Refresh() end
            return
        end
        if prefix ~= PREFIX or ns.Secret(text) or ns.Secret(sender) then return end
        local who = Short(sender)
        if not who or who == (UnitName and UnitName("player")) then return end
        if text == "Q1" then
            ns.Group_Broadcast(true)
            return
        end
        local bags, craft = text:match("^H1|([%d,]*)|([%d,]*)$")
        if bags then
            ns.group[who] = { bags = Decode(bags), craft = Decode(craft), t = GetTime() }
            if ns.Window_Refresh then ns.Window_Refresh() end
        end
    end)
end

-- Plan for the camp: one object per player, prefer objects that are
-- already crafted, never two of the same, skip what is already there.
-- Returns list of { who, key, ready } sorted by name.
function ns.Group_Plan()
    local me = UnitName and UnitName("player") or "?"
    local members = { [me] = { bags = {}, craft = {} } }
    for _, obj in ipairs(ns.OBJECTS) do
        local st = ns.Status(obj)
        if st == "bags" then members[me].bags[obj.key] = true
        elseif st == "craft" then members[me].craft[obj.key] = true end
    end
    for name, info in pairs(ns.group) do members[name] = info end

    local taken = {}
    for key in pairs(ns.camp) do taken[key] = true end
    local names = {}
    for name in pairs(members) do names[#names + 1] = name end
    table.sort(names)

    -- buffs first (they help everyone), then stations, higher tier first
    local order = {}
    for _, obj in ipairs(ns.OBJECTS) do order[#order + 1] = obj end
    table.sort(order, function(a, b)
        local ab, bb = a.aura and 1 or 0, b.aura and 1 or 0
        if ab ~= bb then return ab > bb end
        return a.skill > b.skill
    end)

    local plan, busy = {}, {}
    for pass = 1, 2 do
        local field = pass == 1 and "bags" or "craft"
        for _, obj in ipairs(order) do
            if not taken[obj.key] then
                for _, name in ipairs(names) do
                    if not busy[name] and members[name][field][obj.key] then
                        plan[#plan + 1] = { who = name, key = obj.key, ready = pass == 1 }
                        busy[name], taken[obj.key] = true, true
                        break
                    end
                end
            end
        end
    end
    table.sort(plan, function(a, b) return a.who < b.who end)
    local others = 0
    for _ in pairs(ns.group) do others = others + 1 end
    return plan, others
end
