--=====================================================================
--  Campfire by Felix - Core
--  Your professions, what you can place / craft / still have to learn,
--  the fire next to you, the shared camp cooldown and buff conflicts.
--  No external libraries.
--=====================================================================

local ADDON_NAME, ns = ...
ns.name    = ADDON_NAME
ns.VERSION = (C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(ADDON_NAME, "Version"))
          or (GetAddOnMetadata and GetAddOnMetadata(ADDON_NAME, "Version")) or ""
ns.BRAND   = "|cffff9a3cCAMPFIRE|r by Felix"

local defaults = {
    autoOpen  = true,      -- open the window when you reach a fire
    autoClose = true,      -- close it again when you walk away
    groupSync = true,      -- tell party/raid members what you can bring
    point     = { "CENTER", "CENTER", 0, 40 },
    minimap   = { hide = false, angle = 200 },
    page      = "overview",
}

--------------------------------------------------------------------
-- secret-value safety (WoW Forever hides some values in combat)
--------------------------------------------------------------------
local function Secret(v)
    return issecretvalue and issecretvalue(v) or false
end
ns.Secret = Secret

local function AurasHidden()
    if InCombatLockdown and InCombatLockdown() then return true end
    if C_Secrets and C_Secrets.ShouldAurasBeSecret then
        local ok, hidden = pcall(C_Secrets.ShouldAurasBeSecret)
        if not ok or hidden then return true end
    end
    return false
end
ns.AurasHidden = AurasHidden

-- true / false, or nil when the game does not let us look right now
function ns.HasAura(spellID)
    if AurasHidden() then return nil end
    if C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID then
        local ok, aura = pcall(C_UnitAuras.GetPlayerAuraBySpellID, spellID)
        if not ok or Secret(aura) then return nil end
        return aura ~= nil, aura
    end
    return nil
end

--------------------------------------------------------------------
-- localized names from the client
--------------------------------------------------------------------
function ns.SpellName(id)
    if not id then return nil end
    if C_Spell and C_Spell.GetSpellInfo then
        local info = C_Spell.GetSpellInfo(id)
        if info then return info.name, info.iconID end
    elseif GetSpellInfo then
        local name, _, icon = GetSpellInfo(id)
        return name, icon
    end
end

function ns.SpellDesc(id)
    if not id then return nil end
    if C_Spell and C_Spell.GetSpellDescription then
        if C_Spell.RequestLoadSpellData then pcall(C_Spell.RequestLoadSpellData, id) end
        local d = C_Spell.GetSpellDescription(id)
        if d and d ~= "" and not Secret(d) then return d end
    elseif GetSpellDescription then
        local d = GetSpellDescription(id)
        if d and d ~= "" then return d end
    end
end

local itemWaiting = {}
function ns.ItemName(id)
    if not id then return nil end
    local name
    if C_Item and C_Item.GetItemNameByID then name = C_Item.GetItemNameByID(id)
    elseif GetItemInfo then name = GetItemInfo(id) end
    if not name and not itemWaiting[id] then
        itemWaiting[id] = true
        if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
    end
    return name
end

function ns.ItemIcon(id)
    if not id then return nil end
    if C_Item and C_Item.GetItemIconByID then return C_Item.GetItemIconByID(id) end
    if GetItemIcon then return GetItemIcon(id) end
end

function ns.ItemCount(id, bank)
    if not id then return 0 end
    if C_Item and C_Item.GetItemCount then return C_Item.GetItemCount(id, bank) or 0 end
    if GetItemCount then return GetItemCount(id, bank) or 0 end
    return 0
end

function ns.PlaceName(key)
    local p = ns.PLACES[key]
    if not p then return nil end
    if p.inst and GetRealZoneText then
        local n = GetRealZoneText(p.inst)
        if n and n ~= "" then return n end
    end
    if rawget(ns.L, "place_" .. key) then return ns.L["place_" .. key] end
    if p.map and C_Map and C_Map.GetMapInfo then
        local info = C_Map.GetMapInfo(p.map)
        if info and info.name and info.name ~= "" then return info.name end
    end
    return p.place
end

local faction
function ns.ObjItem(obj)
    faction = faction or (UnitFactionGroup and UnitFactionGroup("player"))
    if faction == "Horde" and obj.itemHorde then return obj.itemHorde end
    return obj.item
end
function ns.ObjPlace(obj)
    faction = faction or (UnitFactionGroup and UnitFactionGroup("player"))
    if faction == "Horde" and obj.placeHorde then return obj.placeHorde end
    return obj.place
end

function ns.ObjName(obj)
    return ns.ItemName(ns.ObjItem(obj)) or ns.SpellName(ns.ObjPlace(obj)) or ns.L["obj_" .. obj.key] or obj.key
end

function ns.ObjIcon(obj)
    return ns.ItemIcon(ns.ObjItem(obj)) or select(2, ns.SpellName(ns.ObjPlace(obj))) or ns.ICON
end

function ns.ObjEffect(obj)
    return ns.SpellDesc(ns.ObjPlace(obj)) or ns.L["eff_" .. obj.key] or ""
end

--------------------------------------------------------------------
-- professions (by skill line, so it works in every language)
--------------------------------------------------------------------
ns.skills = {}
local LINE_TO_KEY = {}
for _, p in ipairs(ns.PROFESSIONS) do LINE_TO_KEY[p.line] = p.key end

function ns.ProfName(key)
    for _, p in ipairs(ns.PROFESSIONS) do
        if p.key == key then return ns.SpellName(p.spells[1]) or ns.L["prof_" .. key] or key end
    end
    return key
end

function ns.ProfByKey(key)
    for _, p in ipairs(ns.PROFESSIONS) do if p.key == key then return p end end
end

function ns.ScanSkills()
    local skills = {}
    if GetProfessions and GetProfessionInfo then
        local list = { GetProfessions() }
        for i = 1, 6 do
            local idx = list[i]
            if idx then
                local _, _, rank, maxRank, _, _, line = GetProfessionInfo(idx)
                local key = LINE_TO_KEY[line]
                if key then skills[key] = { rank = rank or 0, max = maxRank or 0 } end
            end
        end
    end
    -- the old skill list also has First Aid, which GetProfessions can miss
    if GetNumSkillLines and GetSkillLineInfo then
        local byName = {}
        for _, p in ipairs(ns.PROFESSIONS) do
            for _, id in ipairs(p.spells) do
                local n = ns.SpellName(id)
                if n then byName[n:lower()] = p.key end
            end
        end
        for i = 1, GetNumSkillLines() do
            local name, header, _, rank, _, _, maxRank = GetSkillLineInfo(i)
            local key = name and not header and byName[name:lower()]
            if key and not skills[key] then skills[key] = { rank = rank or 0, max = maxRank or 0 } end
        end
    end
    ns.skills = skills
    return skills
end

--------------------------------------------------------------------
-- What this character can do with one camp object
--   bags   the object is in your bags: go place it
--   craft  recipe known, skill high enough: craft it
--   learn  skill high enough, recipe not learned yet (trainer / blueprint)
--   skill  profession learned, skill too low (second value: missing points)
--   none   profession not learned
--------------------------------------------------------------------
local function RecipeKnown(obj)
    if not obj.recipe then return true end
    if IsPlayerSpell then
        if IsPlayerSpell(obj.recipe) then return true end
        if obj.key == "banner" and IsPlayerSpell(1263425) then return true end
        -- unknown ID on this build: do not claim the recipe is missing
        if not ns.SpellName(obj.recipe) then return true end
        return false
    end
    return true
end
ns.RecipeKnown = RecipeKnown

function ns.Status(obj)
    if ns.ItemCount(ns.ObjItem(obj)) > 0 then return "bags" end
    local s = ns.skills[obj.prof]
    if not s then return "none" end
    if s.rank < obj.skill then return "skill", obj.skill - s.rank end
    if not RecipeKnown(obj) then return "learn" end
    return "craft"
end

-- reagents of an object: list of { id, name, need, have, bank }
function ns.Reagents(obj)
    local list = {}
    if obj.recipe and C_TradeSkillUI and C_TradeSkillUI.GetRecipeSchematic then
        local ok, schem = pcall(C_TradeSkillUI.GetRecipeSchematic, obj.recipe, false)
        if ok and schem and schem.reagentSlotSchematics then
            for _, slot in ipairs(schem.reagentSlotSchematics) do
                local r = slot.reagents and slot.reagents[1]
                local id = r and r.itemID
                if id then
                    list[#list + 1] = {
                        id = id, name = ns.ItemName(id) or ("item:" .. id),
                        need = slot.quantityRequired or 1,
                        have = ns.ItemCount(id, false), bank = ns.ItemCount(id, true),
                    }
                end
            end
        end
    end
    return list
end

--------------------------------------------------------------------
-- buff conflicts: a class buff on you that the camp buff won't stack with
--------------------------------------------------------------------
local conflictNames
local function ConflictNames()
    if conflictNames then return conflictNames end
    local t = {}
    for key, ids in pairs(ns.CONFLICTS) do
        for _, id in ipairs(ids) do
            local n = ns.SpellName(id)
            if n then t[n] = key end
        end
    end
    conflictNames = t
    return t
end

ns.activeConflicts = {}
function ns.ConflictKey()
    local keys = {}
    for k in pairs(ns.activeConflicts) do keys[#keys + 1] = k end
    table.sort(keys)
    return table.concat(keys, ",")
end

function ns.ScanConflicts()
    if AurasHidden() then return end
    local found, names = {}, ConflictNames()
    if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
        for i = 1, 40 do
            local ok, a = pcall(C_UnitAuras.GetAuraDataByIndex, "player", i, "HELPFUL")
            if not ok or not a then break end
            if not Secret(a.name) and a.name then
                local key = names[a.name]
                if key then found[key] = a.name end
            end
        end
    end
    ns.activeConflicts = found
end

function ns.Conflict(obj)
    return obj.conflict and ns.activeConflicts[obj.conflict]
end

--------------------------------------------------------------------
-- camp cooldown (all camp objects share one hour)
--------------------------------------------------------------------
function ns.CampCooldown()
    local best
    for _, obj in ipairs(ns.OBJECTS) do
        local id = ns.ObjItem(obj)
        if ns.ItemCount(id) > 0 then
            local start, dur
            if C_Container and C_Container.GetItemCooldown then start, dur = C_Container.GetItemCooldown(id)
            elseif GetItemCooldown then start, dur = GetItemCooldown(id) end
            if start and dur and not Secret(start) and start > 0 and dur > 1.5 then
                local left = start + dur - GetTime()
                if left > 0 and (not best or left > best) then best = left end
            end
            if best == nil then best = 0 end
        end
    end
    return best   -- nil: nothing in bags to tell, 0: ready, n: seconds
end

function ns.CampBuffLeft()
    local has, aura = ns.HasAura(ns.AURA.BENEFITS)
    if has and aura and aura.expirationTime and not Secret(aura.expirationTime) and aura.expirationTime > 0 then
        return aura.expirationTime - GetTime()
    end
    return has == false and 0 or nil
end

--------------------------------------------------------------------
-- the fire: "Campfire Nearby" aura, your own kit cast and object hovers
--------------------------------------------------------------------
ns.nearFire = false
ns.fireKey  = nil         -- basic / journeyman / expert once known
ns.camp     = {}          -- object key -> time first seen at this fire

local FIRE_PLACE, FIRE_GO = {}, { [529161] = "basic", [630660] = "journeyman", [650137] = "expert" }
for _, f in ipairs(ns.FIRES) do FIRE_PLACE[f.place] = f.key end
local GO_TO_OBJ = {
    [651948] = "manawell", [612120] = "fermenter", [612139] = "alchlab",
    [651950] = "sharpening", [612125] = "anvil", [612136] = "masterforge",
    [651952] = "lute", [612130] = "salvager", [612143] = "arcaneforge",
    [242498] = "reagentbot", [254695] = "repairbot", [612145] = "workbench",
    [651955] = "candle", [612087] = "greenhouse", [260105] = "hybridizer",
    [528996] = "tent", [612122] = "tanning", [612140] = "sewing",
    [651956] = "lodestone", [654285] = "rockgarden", [612134] = "foundry",
    [612275] = "chair", [612088] = "fieldguide", [612082] = "trapper",
    [612351] = "banner", [612350] = "banner", [612123] = "spinning", [612142] = "loom",
    [612073] = "feast", [612132] = "oven",
    [651953] = "firstaidkit", [612091] = "toxin", [612110] = "plaguelab",
    [651954] = "fishbowl", [612090] = "fishrack", [612092] = "fishhut",
}
local PLACE_TO_OBJ = {}
for _, o in ipairs(ns.OBJECTS) do
    PLACE_TO_OBJ[o.place] = o.key
    if o.placeHorde then PLACE_TO_OBJ[o.placeHorde] = o.key end
end

local function SetNear(near)
    if near == ns.nearFire then return end
    ns.nearFire = near
    if near then
        if ns.db.autoOpen and not (InCombatLockdown and InCombatLockdown()) then
            ns.Window_Show(nil, true)
        end
    else
        ns.fireKey = nil
        wipe(ns.camp)
        if ns.db.autoClose and ns.window and ns.window.autoOpened then ns.Window_Hide() end
    end
    if ns.Window_Refresh then ns.Window_Refresh() end
    if ns.Minimap_Refresh then ns.Minimap_Refresh() end
end

function ns.CheckFire()
    local near = ns.HasAura(ns.AURA.NEARBY)
    if near == nil then return end          -- can't look now (combat)
    SetNear(near)
end

local function EntryFromGUID(guid)
    if not guid or Secret(guid) then return nil end
    local kind, id = guid:match("^(%a+)%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")
    return kind, tonumber(id)
end

function ns.SeenEntry(kind, id)
    if not id then return end
    if kind == "GameObject" and FIRE_GO[id] then
        ns.fireKey = FIRE_GO[id]
    elseif GO_TO_OBJ[id] then
        if not ns.camp[GO_TO_OBJ[id]] then ns.camp[GO_TO_OBJ[id]] = GetTime() end
    else
        return
    end
    if ns.Window_Refresh then ns.Window_Refresh() end
end

local function OnTooltip(_, data)
    if not data or not ns.nearFire then return end
    ns.SeenEntry(EntryFromGUID(data.guid))
end

--------------------------------------------------------------------
-- saved variables, events, slash command
--------------------------------------------------------------------
local function CopyDefaults(dst, src)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {}; CopyDefaults(dst[k], v)
            elseif k ~= "point" then CopyDefaults(dst[k], v) end
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

local pending
function ns.Refresh()
    if pending then return end
    pending = true
    local function run()
        pending = false
        ns.ScanSkills()
        ns.ScanConflicts()
        if ns.Window_Refresh then ns.Window_Refresh() end
        if ns.Group_Broadcast then ns.Group_Broadcast() end
    end
    if C_Timer and C_Timer.After then C_Timer.After(0.3, run) else run() end
end

-- Ask the client for every name and description we show, so the first
-- look at the window is already complete (answers arrive as events).
local preloaded
function ns.Preload()
    if preloaded then return end
    preloaded = true
    local function item(id) if id then ns.ItemName(id) end end
    local function spell(id) if id then ns.SpellDesc(id); ns.SpellName(id) end end
    for _, o in ipairs(ns.OBJECTS) do
        item(ns.ObjItem(o)); item(o.blueprint); spell(ns.ObjPlace(o)); spell(o.recipe)
        if o.recipe and C_TradeSkillUI and C_TradeSkillUI.GetRecipeSchematic then
            local ok, schem = pcall(C_TradeSkillUI.GetRecipeSchematic, o.recipe, false)
            if ok and schem and schem.reagentSlotSchematics then
                for _, slot in ipairs(schem.reagentSlotSchematics) do
                    local r = slot.reagents and slot.reagents[1]
                    item(r and r.itemID)
                end
            end
        end
    end
    for _, f in ipairs(ns.FIRES) do item(f.item); item(f.blueprint); item(f.wood); spell(f.place) end
    item(ns.FLINT)
end

-- WoW Forever does not know every Retail event; registering an unknown
-- one is a Lua error, so every event goes through pcall
function ns.SafeRegister(frame, event, unit)
    if unit and frame.RegisterUnitEvent then
        if pcall(frame.RegisterUnitEvent, frame, event, unit) then return true end
    end
    return pcall(frame.RegisterEvent, frame, event)
end

local events = CreateFrame("Frame")
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_ENTERING_WORLD", "SKILL_LINES_CHANGED", "SPELLS_CHANGED",
                     "LEARNED_SPELL_IN_TAB", "BAG_UPDATE_DELAYED", "BAG_UPDATE_COOLDOWN",
                     "PLAYER_REGEN_ENABLED", "GET_ITEM_INFO_RECEIVED", "ITEM_DATA_LOAD_RESULT",
                     "SPELL_DATA_LOAD_RESULT" }) do
    ns.SafeRegister(events, e)
end
ns.SafeRegister(events, "UNIT_AURA", "player")
ns.SafeRegister(events, "UNIT_SPELLCAST_SUCCEEDED", "player")
events:SetScript("OnEvent", function(_, event, arg1, _, arg3)
    if event == "ADDON_LOADED" then
        if arg1 ~= ADDON_NAME then return end
        CampfireByFelixDB = CampfireByFelixDB or {}
        CopyDefaults(CampfireByFelixDB, defaults)
        ns.db = CampfireByFelixDB
        if ns.Window_Init then ns.Window_Init() end
        if ns.Options_Init then ns.Options_Init() end
        if ns.Minimap_Init then ns.Minimap_Init() end
        if ns.Group_Init then ns.Group_Init() end
        if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
            if Enum.TooltipDataType.Object then
                TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Object, OnTooltip)
            end
            if Enum.TooltipDataType.Unit then
                TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, OnTooltip)
            end
        end
        return
    end
    if not ns.db then return end
    if event == "UNIT_AURA" then
        if arg1 ~= "player" then return end
        -- auras change often; only redraw when something we show changed
        local before = ns.ConflictKey()
        ns.CheckFire()
        ns.ScanConflicts()
        if ns.ConflictKey() ~= before and ns.Window_Refresh then ns.Window_Refresh() end
    elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
        if arg1 ~= "player" or Secret(arg3) then return end
        if FIRE_PLACE[arg3] then
            ns.fireKey = FIRE_PLACE[arg3]
            wipe(ns.camp)
        elseif PLACE_TO_OBJ[arg3] then
            ns.camp[PLACE_TO_OBJ[arg3]] = GetTime()
        end
        ns.Refresh()
    elseif event == "PLAYER_REGEN_ENABLED" or event == "PLAYER_ENTERING_WORLD" then
        if event == "PLAYER_ENTERING_WORLD" then ns.Preload() end
        ns.CheckFire()
        ns.Refresh()
    else
        ns.Refresh()
    end
end)

SLASH_CAMPFIREBYFELIX1 = "/cfm"
SLASH_CAMPFIREBYFELIX2 = "/campfirefelix"
SlashCmdList.CAMPFIREBYFELIX = function(msg)
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    if msg == "guide" then
        ns.Window_Show("guide")
    elseif msg == "group" then
        ns.Window_Show("group")
    elseif msg == "auto" then
        ns.db.autoOpen = not ns.db.autoOpen
        print(ns.BRAND .. ": " .. (ns.db.autoOpen and ns.L.msgAutoOn or ns.L.msgAutoOff))
        if ns.Options_Refresh then ns.Options_Refresh() end
    elseif msg == "options" or msg == "config" then
        ns.OpenOptions()
    elseif msg == "help" then
        print(ns.BRAND .. ": " .. ns.L.msgHelp)
    else
        ns.Window_Toggle()
    end
end
