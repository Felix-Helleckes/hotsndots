--=====================================================================
--  Campfire by Felix - Window
--  Left: overview, campfires, group, guide and your twelve professions.
--  Right: the selected page. Each camp object shows its status, the
--  effect (straight from the game, level-scaled, in your language),
--  the reagents you have / need, where to learn it and buttons to
--  craft or place it.
--=====================================================================

local _, ns = ...
local L = ns.L

local W, H = 940, 760
local SIDE_W = 230
local ACCENT = { 1.0, 0.60, 0.24 }

local C = {
    bags  = { 0.35, 0.95, 0.45 },
    craft = { 0.45, 0.80, 1.00 },
    learn = { 1.00, 0.82, 0.25 },
    skill = { 1.00, 0.55, 0.25 },
    none  = { 0.50, 0.50, 0.50 },
    red   = { 1.00, 0.30, 0.30 },
    dim   = { 0.62, 0.62, 0.62 },
    white = { 0.92, 0.92, 0.92 },
}
local STATUS_ORDER = { bags = 1, craft = 2, learn = 3, skill = 4, none = 5 }

local win, content, side = nil, nil, nil
local sideButtons, pages = {}, {}
local securePool = {}

--------------------------------------------------------------------
-- small helpers
--------------------------------------------------------------------
local function Hex(c)
    return string.format("|cff%02x%02x%02x", c[1] * 255, c[2] * 255, c[3] * 255)
end

local function Flat(frame, r, g, b, a, edge)
    if not frame.SetBackdrop then Mixin(frame, BackdropTemplateMixin) end
    frame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    frame:SetBackdropColor(r, g, b, a)
    local e = edge or 0.22
    frame:SetBackdropBorderColor(e, e, e, 1)
end

local function Text(parent, font, size, color)
    local fs = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlight")
    if size then
        local f = fs:GetFont()
        if f then fs:SetFont(f, size, "") end
    end
    if color then fs:SetTextColor(color[1], color[2], color[3]) end
    fs:SetJustifyH("LEFT")
    return fs
end

local function Button(parent, label, w)
    local b = CreateFrame("Button", nil, parent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    b:SetSize(w or 120, 24)
    Flat(b, 0.14, 0.14, 0.15, 1, 0.30)
    b.label = Text(b, "GameFontHighlight", 12)
    b.label:SetPoint("CENTER")
    b.label:SetText(label)
    b:SetScript("OnEnter", function(self) self:SetBackdropBorderColor(ACCENT[1], ACCENT[2], ACCENT[3], 1) end)
    b:SetScript("OnLeave", function(self) self:SetBackdropBorderColor(0.30, 0.30, 0.30, 1) end)
    return b
end

local function Clock(sec)
    if not sec then return "-" end
    if sec <= 0 then return L.ready end
    if sec >= 3600 then return string.format("%d:%02d h", sec / 3600, (sec % 3600) / 60) end
    return string.format("%d min", math.ceil(sec / 60))
end

local function StatusText(st, missing)
    if st == "bags" then return L.stBags
    elseif st == "craft" then return L.stCraft
    elseif st == "learn" then return L.stLearn
    elseif st == "skill" then return string.format(L.stSkill, missing or 0)
    end
    return L.stNone
end

local function SourceText(obj)
    if not obj.blueprint then
        if obj.recipe or obj.key ~= "basic" then return L.srcTrainer end
        return L.srcTrainerCooking
    end
    local bp = ns.ItemName(obj.blueprint) or L.blueprint
    local where = obj.at and ns.PlaceName(obj.at)
    local s = bp
    if obj.boss then s = s .. " - " .. (L["boss_" .. obj.key] or obj.boss) end
    if where then s = s .. " (" .. where .. ")" end
    if ns.ItemCount(obj.blueprint) > 0 then s = s .. "  " .. Hex(C.bags) .. L.bpInBags .. "|r" end
    return s
end
ns.SourceText = SourceText

local function ReagentText(obj)
    local list = ns.Reagents(obj)
    if obj.wood then
        -- campfire kits: wood is the reagent, Flint and Tinder the tool
        list = {}
        for _, id in ipairs({ obj.wood, ns.FLINT }) do
            list[#list + 1] = { id = id, name = ns.ItemName(id) or ("item:" .. id), need = 1,
                                have = ns.ItemCount(id, false), bank = ns.ItemCount(id, true) }
        end
    end
    if #list == 0 then return Hex(C.dim) .. (obj.reagents or "") .. "|r" end
    local parts = {}
    for _, r in ipairs(list) do
        local c = (r.have >= r.need) and C.bags or ((r.bank >= r.need) and C.learn or C.red)
        local extra = (r.have < r.need and r.bank >= r.need) and (" " .. L.inBank) or ""
        parts[#parts + 1] = string.format("%s%s %d/%d%s|r", Hex(c), r.name, r.have, r.need, extra)
    end
    return table.concat(parts, Hex(C.dim) .. ",|r  ")
end

--------------------------------------------------------------------
-- secure "place" buttons (using an item is a protected action)
--------------------------------------------------------------------
-- Every card owns one secure button, created once and never moved or
-- reparented. It is only touched when the item or the visibility really
-- changes - re-hiding a secure button between mouse-down and mouse-up
-- swallows the click.
local function NewPlaceButton(card)
    local b = CreateFrame("Button", nil, card, "SecureActionButtonTemplate")
    b:SetSize(180, 24)
    b:SetFrameLevel(card:GetFrameLevel() + 10)
    b:RegisterForClicks("AnyUp", "AnyDown")   -- the template fires once, honoring ActionButtonUseKeyDown
    b:SetAttribute("type", "item")
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.16, 0.34, 0.12, 1)
    b.edge = b:CreateTexture(nil, "BORDER")
    b.edge:SetPoint("TOPLEFT", -1, 1)
    b.edge:SetPoint("BOTTOMRIGHT", 1, -1)
    b.edge:SetColorTexture(0.35, 0.35, 0.35, 1)
    bg:SetDrawLayer("ARTWORK", -1)
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 0.6, 0.24, 0.25)
    b.label = Text(b, "GameFontHighlight", 12)
    b.label:SetPoint("CENTER")
    b:Hide()
    securePool[#securePool + 1] = b
    return b
end

local function SetPlaceButton(b, itemID)
    if InCombatLockdown and InCombatLockdown() then return end
    if itemID then
        local value = ns.ItemName(itemID) or ("item:" .. itemID)
        if b:GetAttribute("item") ~= value then b:SetAttribute("item", value) end
        b.label:SetText(ns.nearFire and L.btnPlace or L.btnPlaceNoFire)
        if not b:IsShown() then b:Show() end
    elseif b:IsShown() then
        b:Hide()
    end
end

--------------------------------------------------------------------
-- object card (profession pages and the fire page)
--------------------------------------------------------------------
local CARD_H = 180

local function NewCard(parent)
    local c = CreateFrame("Frame", nil, parent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    c:SetHeight(CARD_H)
    Flat(c, 0.09, 0.09, 0.10, 1, 0.20)

    c.icon = c:CreateTexture(nil, "ARTWORK")
    c.icon:SetSize(40, 40)
    c.icon:SetPoint("TOPLEFT", 12, -12)

    c.name = Text(c, "GameFontNormalLarge", 15)
    c.name:SetPoint("TOPLEFT", c.icon, "TOPRIGHT", 10, -1)

    c.tier = Text(c, "GameFontHighlightSmall", 11, C.dim)
    c.tier:SetPoint("TOPLEFT", c.name, "BOTTOMLEFT", 0, -3)

    c.status = Text(c, "GameFontHighlight", 12)
    c.status:SetPoint("TOPRIGHT", -12, -14)
    c.status:SetJustifyH("RIGHT")

    c.effect = Text(c, "GameFontHighlight", 12, C.white)
    c.effect:SetPoint("TOPLEFT", c.icon, "BOTTOMLEFT", 0, -8)
    c.effect:SetPoint("RIGHT", c, "RIGHT", -200, 0)
    c.effect:SetWordWrap(true)
    c.effect:SetMaxLines(2)

    c.src = Text(c, "GameFontHighlightSmall", 11, C.dim)
    c.src:SetPoint("TOPLEFT", c.effect, "BOTTOMLEFT", 0, -6)
    c.src:SetPoint("RIGHT", c, "RIGHT", -270, 0)

    c.reag = Text(c, "GameFontHighlightSmall", 11)
    c.reag:SetPoint("TOPLEFT", c.src, "BOTTOMLEFT", 0, -4)
    c.reag:SetPoint("RIGHT", c, "RIGHT", -270, 0)
    c.reag:SetWordWrap(true)

    c.conflict = Text(c, "GameFontHighlightSmall", 11, C.dim)
    c.conflict:SetPoint("TOPLEFT", c.reag, "BOTTOMLEFT", 0, -4)
    c.conflict:SetPoint("RIGHT", c, "RIGHT", -270, 0)

    c.craftBtn = Button(c, L.btnCraft, 180)
    c.craftBtn:SetPoint("BOTTOMRIGHT", -12, 12)
    c.place = NewPlaceButton(c)
    c.place:SetPoint("BOTTOMRIGHT", c.craftBtn, "TOPRIGHT", 0, 6)

    -- hover the card: the game's own item tooltip (what it does) + our info
    c:EnableMouse(true)
    c:SetScript("OnEnter", function(self)
        self:SetBackdropBorderColor(ACCENT[1], ACCENT[2], ACCENT[3], 1)
        if self.obj then ns.ObjTooltip(self, self.obj, self.isFire) end
    end)
    c:SetScript("OnLeave", function(self)
        self:SetBackdropBorderColor(0.20, 0.20, 0.20, 1)
        GameTooltip:Hide()
    end)
    return c
end

-- Tooltip for a camp object or campfire kit: the item tooltip from the
-- game (name, "Use:" text with the real, level-scaled effect), then
-- where to learn it, reagents and buff conflict.
function ns.ObjTooltip(owner, obj, isFire, hint)
    local itemID = isFire and obj.item or ns.ObjItem(obj)
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    local ok = itemID and GameTooltip.SetItemByID and pcall(GameTooltip.SetItemByID, GameTooltip, itemID)
    if not ok or GameTooltip:NumLines() == 0 then
        GameTooltip:ClearLines()
        GameTooltip:AddLine(isFire and (ns.ItemName(obj.item) or L["fire_" .. obj.key]) or ns.ObjName(obj), 1, 0.82, 0)
        local eff = ns.SpellDesc(isFire and obj.place or ns.ObjPlace(obj)) or (isFire and L.fireEffect or ns.ObjEffect(obj))
        if eff ~= "" then GameTooltip:AddLine(eff, 1, 1, 1, true) end
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(Hex(ACCENT) .. ns.BRAND .. "|r")
    GameTooltip:AddLine(L.source .. ": |cffffffff" .. SourceText(obj) .. "|r", 1, 0.82, 0, true)
    GameTooltip:AddLine(L.reagents .. ": " .. ReagentText(obj), 1, 0.82, 0, true)
    if not isFire and obj.conflict then
        local active = ns.Conflict(obj)
        local buff = active or ns.SpellName(ns.CONFLICTS[obj.conflict][1]) or obj.conflict
        if active then
            GameTooltip:AddLine(string.format(L.conflictActive, buff), 1, 0.3, 0.3, true)
        else
            GameTooltip:AddLine(string.format(L.conflictInfo, buff), 0.7, 0.7, 0.7, true)
        end
    end
    if hint then GameTooltip:AddLine(hint, 0.5, 0.5, 0.5) end
    GameTooltip:Show()
end

local function FillCard(c, obj, isFire)
    c.obj, c.isFire = obj, isFire
    local itemID = isFire and obj.item or ns.ObjItem(obj)
    local name = isFire and (ns.ItemName(obj.item) or L["fire_" .. obj.key]) or ns.ObjName(obj)
    c.icon:SetTexture(isFire and (ns.ItemIcon(obj.item) or ns.ICON) or ns.ObjIcon(obj))

    local st, missing
    if isFire then
        if ns.ItemCount(obj.item) > 0 then st = "bags"
        else
            local s = ns.skills.cooking
            if not s then st = "none"
            elseif s.rank < obj.skill then st, missing = "skill", obj.skill - s.rank
            elseif not ns.RecipeKnown(obj) then st = "learn"
            else st = "craft" end
        end
    else
        st, missing = ns.Status(obj)
    end
    local col = C[st]
    c.name:SetText(name)
    c.name:SetTextColor(col[1], col[2], col[3])
    c.icon:SetDesaturated(st == "none")

    local profName = ns.ProfName(isFire and "cooking" or obj.prof)
    if isFire then
        c.tier:SetText(string.format(L.fireTier, profName, obj.skill, obj.sockets))
    else
        c.tier:SetText(string.format(L.objTier, profName, obj.skill))
    end

    local stText = StatusText(st, missing)
    if not isFire and ns.camp[obj.key] then stText = L.atFire end
    if ns.ItemCount(itemID) > 1 then stText = stText .. " (" .. ns.ItemCount(itemID) .. ")" end
    c.status:SetText(stText)
    c.status:SetTextColor(col[1], col[2], col[3])

    c.effect:SetText(ns.SpellDesc(isFire and obj.place or ns.ObjPlace(obj)) or (isFire and L.fireEffect or ns.ObjEffect(obj)))
    c.src:SetText(L.source .. ": " .. SourceText(obj))
    c.reag:SetText(L.reagents .. ": " .. ReagentText(obj))

    local cf = not isFire and obj.conflict
    if cf then
        local active = ns.Conflict(obj)
        local buff = active or ns.SpellName(ns.CONFLICTS[cf][1]) or cf
        if active then
            c.conflict:SetText(Hex(C.red) .. string.format(L.conflictActive, buff) .. "|r")
        else
            c.conflict:SetText(string.format(L.conflictInfo, buff))
        end
        c.conflict:Show()
    else
        c.conflict:Hide()
    end

    -- craft button: open the profession window
    local line = ns.ProfByKey(isFire and "cooking" or obj.prof).line
    c.craftBtn:SetShown(st == "craft" or st == "bags")
    c.craftBtn:SetScript("OnClick", function()
        if C_TradeSkillUI and C_TradeSkillUI.OpenTradeSkill then
            C_TradeSkillUI.OpenTradeSkill(line)
        else
            print(ns.BRAND .. ": " .. L.msgOpenProf)
        end
    end)

    -- place button (secure): the card's own, only updated when needed
    SetPlaceButton(c.place, st == "bags" and itemID or nil)
end

--------------------------------------------------------------------
-- pages
--------------------------------------------------------------------
local function NewPage(key)
    local p = CreateFrame("Frame", nil, content)
    p:SetAllPoints()
    p:Hide()
    p.key = key
    pages[key] = p
    p.title = Text(p, "GameFontNormalLarge", 18, ACCENT)
    p.title:SetPoint("TOPLEFT", 16, -14)
    p.sub = Text(p, "GameFontHighlightSmall", 12, C.dim)
    p.sub:SetPoint("TOPLEFT", p.title, "BOTTOMLEFT", 0, -4)
    p.sub:SetPoint("RIGHT", p, "RIGHT", -16, 0)
    return p
end

local function ScrollArea(p, top)
    local sf = CreateFrame("ScrollFrame", nil, p, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT", 12, top)
    sf:SetPoint("BOTTOMRIGHT", -30, 12)
    local child = CreateFrame("Frame", nil, sf)
    child:SetSize(W - SIDE_W - 60, 10)
    sf:SetScrollChild(child)
    p.scroll, p.child = sf, child
    return child
end

-- profession page: up to three cards
local function ProfessionPage(prof)
    local p = pages["prof_" .. prof.key] or NewPage("prof_" .. prof.key)
    if not p.cards then
        p.cards = {}
        for i = 1, 3 do
            local c = NewCard(p)
            c.page = p
            c:SetPoint("TOPLEFT", 12, -60 - (i - 1) * (CARD_H + 8))
            c:SetPoint("RIGHT", p, "RIGHT", -12, 0)
            p.cards[i] = c
        end
    end
    local s = ns.skills[prof.key]
    p.title:SetText(ns.ProfName(prof.key))
    p.sub:SetText(s and string.format(L.profSkill, s.rank, s.max) or L.profNone)
    local list = {}
    for _, obj in ipairs(ns.OBJECTS) do
        if obj.prof == prof.key then list[#list + 1] = obj end
    end
    if prof.key == "cooking" then table.insert(list, 1, "fire") end
    for i = 1, 3 do
        local c, obj = p.cards[i], list[i]
        if obj == "fire" then
            FillCard(c, ns.FIRES[1], true); c:Show()
        elseif obj then
            FillCard(c, obj); c:Show()
        else
            c:Hide()
        end
    end
    return p
end

local function FirePage()
    local p = pages.fire or NewPage("fire")
    if not p.cards then
        p.cards = {}
        for i = 1, 3 do
            local c = NewCard(p)
            c.page = p
            c:SetPoint("TOPLEFT", 12, -60 - (i - 1) * (CARD_H + 8))
            c:SetPoint("RIGHT", p, "RIGHT", -12, 0)
            p.cards[i] = c
        end
    end
    p.title:SetText(L.navFire)
    p.sub:SetText(L.fireSub)
    for i, f in ipairs(ns.FIRES) do FillCard(p.cards[i], f, true) end
    return p
end

-- overview: everything as a sorted table
local ROW_H = 26
local function OverviewPage()
    local p = pages.overview or NewPage("overview")
    if not p.rows then
        p.rows = {}
        local head = CreateFrame("Frame", nil, p)
        head:SetPoint("TOPLEFT", 16, -58)
        head:SetPoint("RIGHT", p, "RIGHT", -34, 0)
        head:SetHeight(18)
        local cols = { { L.colObject, 0 }, { L.colProfession, 250 }, { L.colStatus, 420 } }
        for _, col in ipairs(cols) do
            local t = Text(head, "GameFontHighlightSmall", 11, C.dim)
            t:SetPoint("LEFT", col[2], 0)
            t:SetText(col[1]:upper())
        end
        ScrollArea(p, -80)
    end
    p.title:SetText(L.navOverview)

    local list = {}
    for _, obj in ipairs(ns.OBJECTS) do
        local st, missing = ns.Status(obj)
        list[#list + 1] = { obj = obj, st = st, missing = missing }
    end
    table.sort(list, function(a, b)
        if STATUS_ORDER[a.st] ~= STATUS_ORDER[b.st] then return STATUS_ORDER[a.st] < STATUS_ORDER[b.st] end
        if a.obj.skill ~= b.obj.skill then return a.obj.skill < b.obj.skill end
        return a.obj.key < b.obj.key
    end)

    local counts = { bags = 0, craft = 0, learn = 0 }
    for i, d in ipairs(list) do
        local r = p.rows[i]
        if not r then
            r = CreateFrame("Button", nil, p.child)
            r:SetHeight(ROW_H)
            r:SetPoint("TOPLEFT", 4, -(i - 1) * ROW_H)
            r:SetPoint("RIGHT", p.child, "RIGHT", 0, 0)
            r.hl = r:CreateTexture(nil, "BACKGROUND")
            r.hl:SetAllPoints()
            r.hl:SetColorTexture(1, 1, 1, 0.05)
            r.hl:Hide()
            r.icon = r:CreateTexture(nil, "ARTWORK")
            r.icon:SetSize(20, 20)
            r.icon:SetPoint("LEFT", 0, 0)
            r.name = Text(r, "GameFontHighlight", 12)
            r.name:SetPoint("LEFT", r.icon, "RIGHT", 8, 0)
            r.name:SetWidth(220)
            r.prof = Text(r, "GameFontHighlight", 12, C.dim)
            r.prof:SetPoint("LEFT", 250, 0)
            r.prof:SetWidth(165)
            r.state = Text(r, "GameFontHighlight", 12)
            r.state:SetPoint("LEFT", 420, 0)
            r:SetScript("OnEnter", function(self)
                self.hl:Show()
                ns.ObjTooltip(self, self.obj, false, L.ttOpenProf)
            end)
            r:SetScript("OnLeave", function(self) self.hl:Hide(); GameTooltip:Hide() end)
            r:SetScript("OnClick", function(self) ns.Window_Show("prof_" .. self.obj.prof) end)
            p.rows[i] = r
        end
        r.obj = d.obj
        local col = C[d.st]
        r.icon:SetTexture(ns.ObjIcon(d.obj))
        r.icon:SetDesaturated(d.st == "none")
        r.name:SetText(ns.ObjName(d.obj))
        r.name:SetTextColor(col[1], col[2], col[3])
        r.prof:SetText(ns.ProfName(d.obj.prof) .. " " .. d.obj.skill)
        local stText = StatusText(d.st, d.missing)
        if ns.camp[d.obj.key] then stText = L.atFire end
        if ns.Conflict(d.obj) then stText = stText .. "  " .. Hex(C.red) .. L.conflictShort .. "|r" end
        r.state:SetText(stText)
        r.state:SetTextColor(col[1], col[2], col[3])
        r:Show()
        if counts[d.st] then counts[d.st] = counts[d.st] + 1 end
    end
    p.child:SetHeight(#list * ROW_H)
    p.sub:SetText(string.format(L.overviewSub, counts.bags, counts.craft, counts.learn))
    return p
end

local function GroupPage()
    local p = pages.group or NewPage("group")
    if not p.lines then
        p.lines = {}
        ScrollArea(p, -64)
    end
    p.title:SetText(L.navGroup)
    local plan, others = ns.Group_Plan()
    if not (IsInGroup and IsInGroup()) then
        p.sub:SetText(L.groupSolo)
    else
        p.sub:SetText(string.format(L.groupSub, others))
    end
    local rows = {}
    for _, e in ipairs(plan) do
        local obj = ns.OBJECTS[ns.OBJECT_INDEX[e.key]]
        rows[#rows + 1] = string.format("%s%s|r  ->  %s%s|r  %s", Hex(ACCENT), e.who,
            Hex(e.ready and C.bags or C.craft), ns.ObjName(obj),
            Hex(C.dim) .. (e.ready and L.planReady or L.planCraft) .. "|r")
    end
    local camp = {}
    for key in pairs(ns.camp) do
        local obj = ns.OBJECTS[ns.OBJECT_INDEX[key]]
        if obj then camp[#camp + 1] = ns.ObjName(obj) end
    end
    if #camp > 0 then
        table.sort(camp)
        rows[#rows + 1] = " "
        rows[#rows + 1] = Hex(C.dim) .. L.alreadyAtFire .. "|r " .. table.concat(camp, ", ")
    end
    if #plan == 0 then rows[#rows + 1] = Hex(C.dim) .. L.planEmpty .. "|r" end
    rows[#rows + 1] = " "
    rows[#rows + 1] = Hex(C.dim) .. L.groupHint .. "|r"
    for i, line in ipairs(rows) do
        local fs = p.lines[i]
        if not fs then
            fs = Text(p.child, "GameFontHighlight", 13)
            fs:SetPoint("TOPLEFT", 6, -(i - 1) * 24)
            fs:SetWidth(W - SIDE_W - 80)
            p.lines[i] = fs
        end
        fs:SetText(line)
        fs:Show()
    end
    for i = #rows + 1, #p.lines do p.lines[i]:Hide() end
    p.child:SetHeight(#rows * 24)
    return p
end

local function GuidePage()
    local p = pages.guide or NewPage("guide")
    if not p.text then
        local child = ScrollArea(p, -64)
        p.text = Text(child, "GameFontHighlight", 13, C.white)
        p.text:SetPoint("TOPLEFT", 6, 0)
        p.text:SetWidth(W - SIDE_W - 80)
        p.text:SetSpacing(4)
    end
    p.title:SetText(L.navGuide)
    p.sub:SetText(L.guideSub)
    local conflicts = {}
    for _, obj in ipairs(ns.OBJECTS) do
        if obj.conflict then
            conflicts[#conflicts + 1] = "  " .. ns.ObjName(obj) .. " - " ..
                (ns.SpellName(ns.CONFLICTS[obj.conflict][1]) or obj.conflict)
        end
    end
    local text = L.guide
        :gsub("%%CONFLICTS%%", function() return table.concat(conflicts, "\n") end)
        :gsub("%%WOOD%%", function() return ns.ItemName(4470) or "Simple Wood" end)
        :gsub("%%FLINT%%", function() return ns.ItemName(ns.FLINT) or "Flint and Tinder" end)
        :gsub("%%BENEFITS%%", function() return ns.SpellName(ns.AURA.BENEFITS) or "Camp Benefits" end)
    p.text:SetText(text)
    p.child:SetHeight((p.text.GetStringHeight and p.text:GetStringHeight() or 600) + 30)
    return p
end

--------------------------------------------------------------------
-- sidebar
--------------------------------------------------------------------
local function SideEntry(i, key, icon, y)
    local b = CreateFrame("Button", nil, side)
    b:SetSize(SIDE_W - 16, 32)
    b:SetPoint("TOPLEFT", 8, y)
    b.bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg:SetAllPoints()
    b.bg:SetColorTexture(1, 1, 1, 0.06)
    b.bg:Hide()
    b.mark = b:CreateTexture(nil, "ARTWORK")
    b.mark:SetSize(3, 32)
    b.mark:SetPoint("LEFT")
    b.mark:SetColorTexture(ACCENT[1], ACCENT[2], ACCENT[3], 1)
    b.mark:Hide()
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetSize(24, 24)
    b.icon:SetPoint("LEFT", 10, 0)
    b.icon:SetTexture(icon)
    b.name = Text(b, "GameFontHighlight", 13)
    b.name:SetPoint("TOPLEFT", b.icon, "TOPRIGHT", 8, 1)
    b.sub = Text(b, "GameFontHighlightSmall", 10, C.dim)
    b.sub:SetPoint("TOPLEFT", b.name, "BOTTOMLEFT", 0, -1)
    b:SetScript("OnEnter", function(self) self.bg:Show() end)
    b:SetScript("OnLeave", function(self) if ns.db.page ~= self.key then self.bg:Hide() end end)
    b:SetScript("OnClick", function(self) ns.Window_Show(self.key) end)
    b.key = key
    sideButtons[i] = b
    return b
end

local function Header(text, y)
    local t = Text(side, "GameFontHighlightSmall", 11, C.dim)
    t:SetPoint("TOPLEFT", 14, y)
    t:SetText(text:upper())
end

local function RefreshSide()
    for _, b in ipairs(sideButtons) do
        local sel = ns.db.page == b.key
        b.mark:SetShown(sel)
        b.bg:SetShown(sel)
        if b.prof then
            local s = ns.skills[b.prof]
            b.name:SetText(ns.ProfName(b.prof))
            b.name:SetTextColor(s and 1 or 0.6, s and 1 or 0.6, s and 1 or 0.6)
            b.icon:SetDesaturated(not s)
            local ready = 0
            for _, obj in ipairs(ns.OBJECTS) do
                if obj.prof == b.prof then
                    local st = ns.Status(obj)
                    if st == "bags" or st == "craft" then ready = ready + 1 end
                end
            end
            if s then
                b.sub:SetText(string.format("%d / %d", s.rank, s.max) ..
                    (ready > 0 and ("  " .. Hex(C.bags) .. string.format(L.sideReady, ready) .. "|r") or ""))
            else
                b.sub:SetText(L.profNone)
            end
        end
    end
end

--------------------------------------------------------------------
-- status strip
--------------------------------------------------------------------
local function RefreshStatus()
    local fireText
    if ns.nearFire then
        local f = ns.fireKey and ns.FireByKey(ns.fireKey)
        if f then
            local used = 0
            for _ in pairs(ns.camp) do used = used + 1 end
            fireText = Hex(C.bags) .. string.format(L.hdrFire, ns.SpellName(f.place) or L["fire_" .. f.key], used, f.sockets) .. "|r"
        else
            fireText = Hex(C.bags) .. L.hdrFireUnknown .. "|r"
        end
    else
        fireText = Hex(C.dim) .. L.hdrNoFire .. "|r"
    end
    win.chipFire:SetText(fireText)
    local cd = ns.CampCooldown()
    win.chipCd:SetText(L.hdrCooldown .. " " .. (cd == nil and Hex(C.dim) .. "-|r"
        or (cd <= 0 and Hex(C.bags) .. L.ready .. "|r" or Hex(C.learn) .. Clock(cd) .. "|r")))
    local buff = ns.CampBuffLeft()
    win.chipBuff:SetText(L.hdrBuff .. " " .. (buff == nil and Hex(C.dim) .. "?|r"
        or (buff <= 0 and Hex(C.dim) .. L.none .. "|r" or Hex(C.bags) .. Clock(buff) .. "|r")))
end

--------------------------------------------------------------------
-- refresh / show / hide
--------------------------------------------------------------------
function ns.Window_Refresh()
    if not win or not win:IsShown() then return end
    RefreshSide()
    RefreshStatus()
    local key = ns.db.page or "overview"
    local p
    if key == "fire" then p = FirePage()
    elseif key == "group" then p = GroupPage()
    elseif key == "guide" then p = GuidePage()
    elseif key:match("^prof_") then
        local prof = ns.ProfByKey(key:sub(6))
        p = prof and ProfessionPage(prof)
    end
    p = p or OverviewPage()
    for _, page in pairs(pages) do
        if page ~= p and page:IsShown() then page:Hide() end
    end
    if not p:IsShown() then p:Show() end
end

function ns.Window_Init()
    win = CreateFrame("Frame", "CampfireByFelixFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    win:SetSize(W, H)
    local pt = ns.db.point
    win:SetPoint(pt[1], UIParent, pt[2], pt[3], pt[4])
    win:SetFrameStrata("HIGH")
    win:SetToplevel(true)
    win:SetClampedToScreen(true)
    win:SetMovable(true)
    win:EnableMouse(true)
    win:RegisterForDrag("LeftButton")
    win:SetScript("OnDragStart", win.StartMoving)
    win:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local a, _, b, x, y = self:GetPoint()
        ns.db.point = { a, b, x, y }
    end)
    Flat(win, 0.05, 0.05, 0.055, 0.97, 0.25)
    win:Hide()
    if UISpecialFrames then tinsert(UISpecialFrames, "CampfireByFelixFrame") end

    -- title bar
    local icon = win:CreateTexture(nil, "ARTWORK")
    icon:SetSize(22, 22)
    icon:SetPoint("TOPLEFT", 16, -12)
    icon:SetTexture(ns.ICON)
    local title = Text(win, "GameFontNormalLarge", 18, C.white)
    title:SetPoint("LEFT", icon, "RIGHT", 8, 0)
    title:SetText(ns.BRAND)
    local ver = Text(win, "GameFontHighlightSmall", 11, C.dim)
    ver:SetPoint("LEFT", title, "RIGHT", 10, -1)
    ver:SetText("v" .. ns.VERSION .. "  -  WoW Forever")

    local close = Button(win, "X", 24)
    close:SetPoint("TOPRIGHT", -10, -10)
    close.label:SetTextColor(1, 0.35, 0.3)
    close:SetScript("OnClick", function() win:Hide() end)

    -- status chips
    local strip = CreateFrame("Frame", nil, win, BackdropTemplateMixin and "BackdropTemplate" or nil)
    strip:SetPoint("TOPLEFT", 8, -44)
    strip:SetPoint("TOPRIGHT", -8, -44)
    strip:SetHeight(30)
    Flat(strip, 0.08, 0.08, 0.09, 1, 0.18)
    win.chipFire = Text(strip, "GameFontHighlight", 12)
    win.chipFire:SetPoint("LEFT", 12, 0)
    win.chipBuff = Text(strip, "GameFontHighlight", 12, C.white)
    win.chipBuff:SetPoint("RIGHT", -12, 0)
    win.chipCd = Text(strip, "GameFontHighlight", 12, C.white)
    win.chipCd:SetPoint("RIGHT", win.chipBuff, "LEFT", -28, 0)

    -- sidebar
    side = CreateFrame("Frame", nil, win, BackdropTemplateMixin and "BackdropTemplate" or nil)
    side:SetPoint("TOPLEFT", 8, -80)
    side:SetPoint("BOTTOMLEFT", 8, 8)
    side:SetWidth(SIDE_W)
    Flat(side, 0.07, 0.07, 0.08, 1, 0.18)

    Header(L.hdrCamp, -8)
    local y, i = -24, 0
    local fixed = {
        { "overview", "Interface\\Icons\\INV_Misc_Note_01", L.navOverview, L.navOverviewSub },
        { "fire",     ns.ICON, L.navFire, L.navFireSub },
        { "group",    "Interface\\Icons\\INV_Misc_GroupNeedMore", L.navGroup, L.navGroupSub },
        { "guide",    "Interface\\Icons\\INV_Misc_Book_09", L.navGuide, L.navGuideSub },
    }
    for _, e in ipairs(fixed) do
        i = i + 1
        local b = SideEntry(i, e[1], e[2], y)
        b.name:SetText(e[3]); b.sub:SetText(e[4])
        y = y - 32
    end
    y = y - 8
    Header(L.hdrProfessions, y)
    y = y - 16
    for _, prof in ipairs(ns.PROFESSIONS) do
        i = i + 1
        local b = SideEntry(i, "prof_" .. prof.key, prof.icon, y)
        b.prof = prof.key
        y = y - 32
    end
    local foot = Text(side, "GameFontHighlightSmall", 10, C.dim)
    foot:SetPoint("BOTTOMLEFT", 12, 8)
    foot:SetText("/cfm  -  /cfm guide")

    -- content
    content = CreateFrame("Frame", nil, win, BackdropTemplateMixin and "BackdropTemplate" or nil)
    content:SetPoint("TOPLEFT", side, "TOPRIGHT", 8, 0)
    content:SetPoint("BOTTOMRIGHT", -8, 8)
    Flat(content, 0.06, 0.06, 0.065, 1, 0.18)

    win:SetScript("OnShow", function() ns.ScanSkills(); ns.ScanConflicts(); ns.Window_Refresh() end)
    win:SetScript("OnHide", function(self) self.autoOpened = false end)
    -- secure buttons can't change in combat: close before it starts
    local guard = CreateFrame("Frame")
    ns.SafeRegister(guard, "PLAYER_REGEN_DISABLED")
    guard:SetScript("OnEvent", function() if win:IsShown() then win:Hide() end end)

    -- refresh timers once a second while open
    local acc = 0
    win:SetScript("OnUpdate", function(_, dt)
        acc = acc + dt
        if acc < 1 then return end
        acc = 0
        RefreshStatus()
    end)
    ns.window = win
end

function ns.Window_Show(page, auto)
    if not win then return end
    if InCombatLockdown and InCombatLockdown() then
        print(ns.BRAND .. ": " .. L.msgCombat)
        return
    end
    if page then ns.db.page = page end
    if win:IsShown() then
        ns.Window_Refresh()
        return
    end
    win.autoOpened = auto and true or false
    if auto and ns.db.page ~= "group" then
        -- at a fire the overview (what can I place?) is the useful page
        ns.db.page = "overview"
    end
    win:Show()
end

function ns.Window_Hide()
    if win and not (InCombatLockdown and InCombatLockdown()) then win:Hide() end
end

function ns.Window_Toggle()
    if not win then return end
    if win:IsShown() then ns.Window_Hide() else ns.Window_Show() end
end
