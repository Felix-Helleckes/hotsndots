--=====================================================================
--  Campfire by Felix - Data
--  Game facts only (IDs from the client, build 1.60.1). Every name and
--  description shown in game is asked from the client at run time, so
--  the addon speaks whatever language your client speaks. The English
--  strings below are only a fallback while the client loads its cache.
--
--  Sources: wago.tools client tables (build 1.60.1.70009 / 71037),
--  wowhead.com/forever, warcrafttavern.com, wow-professions.com.
--=====================================================================

local _, ns = ...

ns.ICON = "Interface\\Icons\\Spell_Fire_Fire"

ns.AURA = {
    NEARBY   = 1283391,   -- "Campfire Nearby": any lit campfire within ~100 yd
    WELCOME  = 1229739,   -- the minute of resting at the fire
    WELCOME2 = 1289723,   -- same, crafting variant
    BENEFITS = 1229741,   -- "Camp Benefits": 1 h (2 h at violet flames)
    TENT     = 1229451,   -- Camp Tent rested-XP lockout, 1 h
}

-- profession key, skill line, profession spell (for its localized name), icon
ns.PROFESSIONS = {
    { key = "alchemy",        line = 171, spells = { 2259 },  icon = "Interface\\Icons\\Trade_Alchemy" },
    { key = "blacksmithing",  line = 164, spells = { 2018 },  icon = "Interface\\Icons\\Trade_BlackSmithing" },
    { key = "enchanting",     line = 333, spells = { 7411 },  icon = "Interface\\Icons\\Trade_Engraving" },
    { key = "engineering",    line = 202, spells = { 4036 },  icon = "Interface\\Icons\\Trade_Engineering" },
    { key = "herbalism",      line = 182, spells = { 2366, 9134 }, icon = "Interface\\Icons\\Trade_Herbalism" },
    { key = "leatherworking", line = 165, spells = { 2108 },  icon = "Interface\\Icons\\Trade_LeatherWorking" },
    { key = "mining",         line = 186, spells = { 2575, 2656 }, icon = "Interface\\Icons\\Trade_Mining" },
    { key = "skinning",       line = 393, spells = { 8613 },  icon = "Interface\\Icons\\INV_Misc_Pelt_Wolf_01" },
    { key = "tailoring",      line = 197, spells = { 3908 },  icon = "Interface\\Icons\\Trade_Tailoring" },
    { key = "cooking",        line = 185, spells = { 2550 },  icon = "Interface\\Icons\\INV_Misc_Food_15" },
    { key = "firstaid",       line = 129, spells = { 3273 },  icon = "Interface\\Icons\\Spell_Holy_SealOfSacrifice" },
    { key = "fishing",        line = 356, spells = { 7620 },  icon = "Interface\\Icons\\Trade_Fishing" },
}

-- Where blueprints drop. inst = instance map ID (localized with
-- GetRealZoneText), map = zone map ID (localized with C_Map),
-- place = English fallback.
ns.PLACES = {
    rfc  = { inst = 389, place = "Ragefire Chasm" },
    dm   = { inst = 36,  place = "The Deadmines" },
    wc   = { inst = 43,  place = "Wailing Caverns" },
    sfk  = { inst = 33,  place = "Shadowfang Keep" },
    bfd  = { inst = 48,  place = "Blackfathom Deeps" },
    sm   = { inst = 189, place = "Scarlet Monastery" },
    st   = { inst = 109, place = "Sunken Temple" },
    brd  = { inst = 230, place = "Blackrock Depths" },
    lbrs = { inst = 229, place = "Lower Blackrock Spire" },
    ubrs = { inst = 229, place = "Upper Blackrock Spire" },
    scholo = { inst = 289, place = "Scholomance" },
    strat  = { inst = 329, place = "Stratholme" },
    dmw    = { inst = 429, place = "Dire Maul (West)" },
    lordaeron = { map = 1420, place = "Ruins of Lordaeron (Tirisfal Glades)" },
    wetlands  = { map = 1437, place = "Excavation Site (Wetlands)" },
    wetlands2 = { map = 1437, place = "Wetlands" },
    dalaran   = { map = 1416, place = "Dalaran (Alterac Mountains)" },
    kroldok   = { place = "Krol'Dok Stronghold" },
}

-- Camp objects. item = the object you carry and use, place = the spell
-- that item casts (its description is the localized, level-scaled
-- effect), recipe = the spell that crafts it, blueprint = item that
-- teaches tiers 2 and 3, boss/at = where that blueprint drops.
-- reagents is the English fallback; in game the real list comes from
-- the recipe itself (C_TradeSkillUI.GetRecipeSchematic).
ns.OBJECTS = {
    -- Alchemy
    { key = "manawell",   prof = "alchemy", skill = 20,  item = 279956, place = 1307259, recipe = 1230564, aura = 1230587,
      conflict = "wisdom", reagents = "Peacebloom, Empty Vial" },
    { key = "fermenter",  prof = "alchemy", skill = 140, item = 279970, place = 1307242, recipe = 1263005,
      blueprint = 273085, boss = "Rath'mael", at = "lordaeron", reagents = "Leaded Vial, Kingsblood, Swiftthistle" },
    { key = "alchlab",    prof = "alchemy", skill = 300, item = 279990, place = 1307172, recipe = 1263078,
      blueprint = 273112, boss = "Ras Frostwhisper", at = "scholo", reagents = "Lich's Index Finger, Crystal Vial, 2 Dreamfoil" },
    -- Blacksmithing
    { key = "sharpening", prof = "blacksmithing", skill = 20, item = 279944, place = 1307392, recipe = 1230171, aura = 1230172,
      conflict = "earth", reagents = "Rough Stone, Copper Bar" },
    { key = "anvil",      prof = "blacksmithing", skill = 140, item = 279988, place = 1307175, recipe = 1263041,
      blueprint = 273086, boss = "Gilnid", at = "dm", reagents = "5 Bronze Bar, 2 Coarse Grinding Stone, 2 Medium Leather" },
    { key = "masterforge", prof = "blacksmithing", skill = 300, item = 279955, place = 1307261, recipe = 1263073,
      blueprint = 273113, boss = "Golem Lord Argelmach", at = "brd", reagents = "Golem Heart, 5 Thorium Bar, 2 Rugged Leather" },
    -- Enchanting
    { key = "lute",       prof = "enchanting", skill = 20, item = 279976, place = 1307234, recipe = 1230643, aura = 1230653,
      conflict = "wild", reagents = "Simple Wood, Strange Dust" },
    { key = "salvager",   prof = "enchanting", skill = 140, item = 279985, place = 1307223, recipe = 1263056,
      blueprint = 273103, reagents = "2 Vision Dust, Lesser Nether Essence" },
    { key = "arcaneforge", prof = "enchanting", skill = 300, item = 279987, place = 1307176, recipe = 1263082,
      blueprint = 273116, boss = "Nanaya", reagents = "Maker's Spark, 2 Large Brilliant Shard, 4 Greater Eternal Essence" },
    -- Engineering
    { key = "reagentbot", prof = "engineering", skill = 20, item = 279950, place = 1307266, recipe = 1230656,
      reagents = "Handful of Copper Bolts, Copper Tube" },
    { key = "repairbot",  prof = "engineering", skill = 140, item = 279949, place = 1307385, recipe = 1263034,
      blueprint = 273092, boss = "Sneed", at = "dm", reagents = "2 Whirring Bronze Gizmo, Bronze Tube, Heavy Leather" },
    { key = "workbench",  prof = "engineering", skill = 300, item = 279989, place = 1307174, recipe = 1263083,
      blueprint = 273117, boss = "Ezra Grimm", at = "strat", reagents = "Essence of Anarchy, 2 Thorium Widget" },
    -- Herbalism
    { key = "candle",     prof = "herbalism", skill = 20, item = 279962, place = 1307251, recipe = 1229705, aura = 1229513,
      conflict = "intellect", reagents = "Peacebloom, Silverleaf" },
    { key = "greenhouse", prof = "herbalism", skill = 140, item = 279964, place = 1307248, recipe = 1262980,
      blueprint = 273106, boss = "Shadetooth", at = "wetlands", reagents = "2 Simple Wood, Arthas' Tears, Purple Lotus" },
    { key = "hybridizer", prof = "herbalism", skill = 300, item = 279947, place = 1307387, recipe = 1263070,
      blueprint = 273120, boss = "Tendris Warpwood", at = "dmw", reagents = "4 Mountain Silversage, Crystal Vial, 2 Runecloth" },
    -- Leatherworking
    { key = "tent",       prof = "leatherworking", skill = 20, item = 279978, place = 1307230, recipe = 1229432,
      reagents = "5 Light Leather" },
    { key = "tanning",    prof = "leatherworking", skill = 140, item = 279941, place = 1307395, recipe = 1263031,
      blueprint = 273096, boss = "Razorclaw the Butcher", at = "sfk", reagents = "5 Medium Leather, 3 Fine Thread, 2 Simple Wood" },
    { key = "sewing",     prof = "leatherworking", skill = 300, item = 279945, place = 1307391, recipe = 1263079,
      blueprint = 273121, boss = "Vectus", at = "scholo", reagents = "Undeath Engine, 5 Rugged Leather, Rune Thread" },
    -- Mining
    { key = "lodestone",  prof = "mining", skill = 20, item = 279960, place = 1307254, recipe = 1230161, aura = 1230164,
      conflict = "might", reagents = "Rough Stone, Copper Bar" },
    { key = "rockgarden", prof = "mining", skill = 140, item = 279948, place = 1307386, recipe = 1262975,
      blueprint = 273097, boss = "Relic Guardian", at = "wetlands2", reagents = "2 Heavy Stone, Iron Ore, Silver Bar" },
    { key = "foundry",    prof = "mining", skill = 300, item = 279952, place = 1307264, recipe = 1263071,
      blueprint = 273122, boss = "Ambassador Flamelash", at = "brd", reagents = "5 Thorium Bar, 2 Dense Stone, Truesilver Bar" },
    -- Skinning
    { key = "chair",      prof = "skinning", skill = 20, item = 279979, place = 1307229, recipe = 1229517, aura = 1229519,
      conflict = "crit", reagents = "3 Light Leather, 2 Simple Wood" },
    { key = "fieldguide", prof = "skinning", skill = 140, item = 279969, place = 1307243, recipe = 1262985,
      blueprint = 273098, boss = "Lady Anacondra", at = "wc", reagents = "3 Medium Leather, 2 Slimy Murloc Scale, Fine Thread" },
    { key = "trapper",    prof = "skinning", skill = 300, item = 279938, place = 1307397, recipe = 1262982,
      blueprint = 273109, boss = "The Beast", at = "ubrs", reagents = "2 Simple Wood, 4 Heavy Leather, Iron Bar" },
    -- Tailoring
    { key = "banner",     prof = "tailoring", skill = 20, item = 279973, itemHorde = 279972, place = 1307239, placeHorde = 1307240,
      recipe = 1229504, aura = 1229718, conflict = "spirit", reagents = "Bolt of Linen Cloth, Coarse Thread" },
    { key = "spinning",   prof = "tailoring", skill = 140, item = 279943, place = 1307393, recipe = 1263032,
      blueprint = 273099, boss = "Unstable Sentinel", at = "dalaran", reagents = "2 Simple Wood, 5 Bolt of Silk Cloth, 3 Fine Thread" },
    { key = "loom",       prof = "tailoring", skill = 300, item = 279959, place = 1307255, recipe = 1263080,
      blueprint = 273124, boss = "Baroness Anastari", at = "strat", reagents = "Bottled Screams, 4 Bolt of Runecloth, 4 Simple Wood" },
    -- Cooking (the campfire kit is its first object)
    { key = "feast",      prof = "cooking", skill = 140, item = 279957, place = 1307257, recipe = 1262978,
      blueprint = 273102, boss = "Cookie", at = "dm", reagents = "2 Mystery Meat, Heavy Kodo Meat, Soothing Spices" },
    { key = "oven",       prof = "cooking", skill = 300, item = 279982, place = 1307226, recipe = 1263067,
      blueprint = 273115, boss = "Quartermaster Zigris", at = "lbrs", reagents = "10 Simple Flour, 5 Refreshing Spring Water, 4 Soothing Spices" },
    -- First Aid
    { key = "firstaidkit", prof = "firstaid", skill = 20, item = 279968, place = 1307244, recipe = 1230117, aura = 1230124,
      conflict = "fortitude", reagents = "3 Linen Bandage, Refreshing Spring Water" },
    { key = "toxin",      prof = "firstaid", skill = 140, item = 279940, place = 1307396, recipe = 1262996,
      blueprint = 273105, boss = "Commander Springvale", at = "sfk", reagents = "Anti-Venom, 2 Mageweave Bandage, 2 Simple Wood" },
    { key = "plaguelab",  prof = "firstaid", skill = 300, item = 279951, place = 1307265, recipe = 1263001,
      blueprint = 273118, boss = "Doctor Theolen Krastinov", at = "scholo", reagents = "2 Simple Wood, 2 Strong Anti-Venom, 5 Heavy Runecloth Bandage" },
    -- Fishing
    { key = "fishbowl",   prof = "fishing", skill = 20, item = 279967, place = 1307245, recipe = 1229745, aura = 1230098,
      conflict = "kings", reagents = "Raw Brilliant Smallfish, Empty Vial" },
    { key = "fishrack",   prof = "fishing", skill = 140, item = 279965, place = 1307247, recipe = 1262990,
      blueprint = 273141, boss = "Gelihast", at = "bfd", reagents = "2 Simple Wood, Crystal Vial, 2 Raw Mithril Head Trout" },
    { key = "fishhut",    prof = "fishing", skill = 300, item = 279966, place = 1307246, recipe = 1262998,
      blueprint = 273119, boss = "Jammal'an the Prophet", at = "st", reagents = "5 Simple Wood, 2 Bolt of Runecloth, Seasonal Fish Steaks" },
}

-- Campfire kits (Cooking)
ns.FIRES = {
    { key = "basic",      sockets = 3,  item = 279981, place = 1307227, skill = 1,   wood = 4470,
      reagents = "Simple Wood (+ Flint and Tinder)" },
    { key = "journeyman", sockets = 5,  item = 279961, place = 1307252, skill = 90,  wood = 11291, recipe = 1283400,
      blueprint = 273087, boss = "Lord Serpentis", at = "wc", reagents = "Star Wood (+ Flint and Tinder)" },
    { key = "expert",     sockets = 10, item = 279974, place = 1307237, skill = 200, wood = 272941, recipe = 1291341,
      blueprint = 273101, boss = "Slavecrusher Grox", at = "kroldok", reagents = "Thick Logs (+ Flint and Tinder)" },
}
ns.FLINT = 4471

function ns.FireByKey(key)
    for _, f in ipairs(ns.FIRES) do if f.key == key then return f end end
end

-- Class buffs that a camp buff does not stack with. The first ID is
-- used for the localized name; all are checked on the player.
ns.CONFLICTS = {
    wisdom    = { 19742, 19850, 19852, 19853, 19854, 25290, 25894, 25918 },
    earth     = { 8076, 8162, 8163, 10441, 25362 },
    wild      = { 1126, 5232, 6756, 5234, 8907, 9884, 9885, 21849, 21850 },
    intellect = { 1459, 1460, 1461, 10156, 10157, 23028 },
    might     = { 19740, 19834, 19835, 19836, 19837, 19838, 25291, 25782, 25916 },
    crit      = { 24907, 24932 },
    spirit    = { 14752, 14818, 14819, 27841, 27681 },
    fortitude = { 1243, 1244, 1245, 2791, 10937, 10938, 21562, 21564 },
    kings     = { 20217, 25898 },
}

-- index lookups
ns.OBJECT_INDEX = {}
for i, o in ipairs(ns.OBJECTS) do ns.OBJECT_INDEX[o.key] = i end
