# Campfire by Felix

WoW Forever camping in one window. Walk up to a campfire and it opens by itself:

- **What you can place right now**: every camp object of your professions, sorted by "in your bags", "craftable", "recipe to learn", "skill missing".
- **Place with one click**: a secure button uses the object from your bags.
- **Reagents you have / need**, bags and bank, straight from the recipe.
- **Where to learn every object**: trainer, the quest "Camping 101", or the blueprint with boss and dungeon.
- **Buff conflicts**: marks camp objects red when a class buff on you blocks them (Fortitude, Arcane Intellect, Kings, ...).
- **Group plan**: party and raid members running the addon share what they carry, and you get the best split: one object per player, no doubles, buffs first.
- **Camp status**: fire size and slots, the shared 1-hour camp cooldown, your Camp Benefits timer.
- **Guide**: how camping works, short and practical.
- **Every client language**: object, profession, blueprint, dungeon and effect texts come from the game itself. The addon's own texts are translated into all 11 WoW languages.

`/cfm` open / close - `/cfm guide` - `/cfm group` - `/cfm auto` - `/cfm options`

No libraries, no dependencies. Works with button collectors through LibDBIcon if another addon loads it.

## Data

Game IDs from the client tables (wago.tools, build 1.60.1), wowhead.com/forever, warcrafttavern.com and wow-professions.com. All names and effect texts are read from the client at run time.

## Tests

`python tests/smoke_test.py` (needs `pip install lupa`); `WOW_LOCALE=frFR` etc. for other languages.

## License

MIT
